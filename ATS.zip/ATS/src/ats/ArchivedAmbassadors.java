package ats;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Accordion;
import javafx.scene.control.Label;
import javafx.scene.control.TitledPane;

public class ArchivedAmbassadors implements Initializable {

    @FXML
    private Accordion ambassador_list;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        try {
            // add ambassadors to ambassador titlepane list
            DBManager h2 = new DBManager();
            
            ArrayList<String> ambassadorData = h2.getAmbassadorDataArchived();
            ArrayList<TitledPane> panes = new ArrayList<TitledPane>();
            
            for(int i = 0; i < ambassadorData.size(); i++) {
                                
                String uin = ambassadorData.get(i);
                
                if(!(i + 9 > ambassadorData.size())) {
                    
                    panes.add(new TitledPane(ambassadorData.get(i + 1) + " " + ambassadorData.get(i + 2),
                    new Label("UIN: " + uin + System.lineSeparator() +
                        "Email: " + ambassadorData.get(i + 3) + System.lineSeparator() +
                        "Major(s): " + ambassadorData.get(i + 4) + System.lineSeparator() +
                        "Catalog: " + ambassadorData.get(i + 5) + System.lineSeparator() +
                        "Graduation: " + ambassadorData.get(i + 6) + System.lineSeparator() +
                        "Biography: " + ambassadorData.get(i + 7) + System.lineSeparator() +
                        "Hours: " + ambassadorData.get(i + 8)
                    )));
                    
                }
                
                i += 8; // update to next ambassador in list
            }

            ambassador_list.getPanes().addAll(panes);
            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
    }    
    
}
