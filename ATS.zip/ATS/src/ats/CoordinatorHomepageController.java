package ats;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Side;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class CoordinatorHomepageController implements Initializable {
    
    // note that the vboxes have switched places
    
    @FXML
    private VBox pie_chart;
    
    @FXML
    private VBox line_chart;
    
    @FXML
    private VBox today;
    
    @FXML
    private Label upcoming;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // for line chart
        
        //defining the axes
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        
        xAxis.setLabel("Event");
        yAxis.setLabel("Number of Attendees");
        
        //creating the chart
        final LineChart<String,Number> lineChart = new LineChart<String,Number>(xAxis,yAxis);
                
        lineChart.setTitle("Event Attendance");
        
        //defining a series
        XYChart.Series series = new XYChart.Series();
        XYChart.Series series2 = new XYChart.Series();
        
        series.setName("Off Campus");
        series2.setName("On Campus");
        
        try {
            
            DBManager h2 = new DBManager();
            
            ArrayList<String> eventData = h2.getEventData();
            
            for(int i = 0; i < eventData.size(); i++) {
                                
                String id = eventData.get(i);
                
                if(!(i + 13 > eventData.size())) {
                    
                    series.getData().add(new XYChart.Data(eventData.get(i + 1), 
                        h2.countEventAttendees(id)));
                    
                }
                
                i += 12; // update to next ambassador in list
            }

            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
        lineChart.getData().addAll(series, series2);
        pie_chart.getChildren().addAll(lineChart);
        
        
        // now for the pie chart
        
        ObservableList<PieChart.Data> pieChartData;
        
        try {
            
            DBManager h2 = new DBManager();
            
            pieChartData =
                FXCollections.observableArrayList(
                new PieChart.Data("Software", h2.getHoursByMajor("Software Engineering")),
                new PieChart.Data("Environmental", h2.getHoursByMajor("Environmental Engineering")),
                new PieChart.Data("Bio", h2.getHoursByMajor("Bioengineering")),
                new PieChart.Data("Civil", h2.getHoursByMajor("Civil Engineering"))
            );
            
            h2.shutdown();
            
            final PieChart chart = new PieChart(pieChartData);
            
            pieChartData.forEach(
                data -> data.nameProperty().bind(
                    Bindings.concat(
                        data.getName(), System.lineSeparator(), data.pieValueProperty(), " hours"
                    )
                )
            );
            
            // chart.setLegendVisible(false);
            
            chart.setLegendSide(Side.LEFT);
            chart.setLabelsVisible(false);
            
            chart.setTitle("Ambassador Hours by Major");
            line_chart.getChildren().addAll(chart);
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
        // populate today's events
        try {
            
            // get today's date
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String date = sdf.format(new Date()); 
                    
            DBManager h2 = new DBManager();
            
            ArrayList<String> todaysEvents = h2.getTodaysEvents(date);
            String todaysEventsText = new String();
            ArrayList<String> attendees = new ArrayList<String>();
            
            for(int i = 0; i < todaysEvents.size(); i++) {
                
                if(!(i + 9 > todaysEvents.size())) {
                    
                    String id = todaysEvents.get(i); // get ID based on title
                    attendees = h2.getEventAttendees(id);
                    
                    System.out.println(todaysEvents.get(i + 1));
                    
                    /*
                    todaysEventsText += todaysEvents.get(i + 1) + " @ " + todaysEvents.get(i + 2) +
                        ": " + todaysEvents.get(i + 3) + System.lineSeparator() + "Notes: " +
                        todaysEvents.get(i + 4) + System.lineSeparator() + "Dress Code: " +
                        todaysEvents.get(i + 5) + System.lineSeparator() + "Where: " +
                        todaysEvents.get(i + 6) + ", " + todaysEvents.get(i + 7) + ", " +
                        todaysEvents.get(i + 8) + " " + todaysEvents.get(i + 9) + 
                        System.lineSeparator() + "Attendees: " + attendees;
                    */
                    
                    today.getChildren().addAll(new Label(todaysEvents.get(i + 1) + " @ " + todaysEvents.get(i + 2) +
                        ": " + todaysEvents.get(i + 3) + System.lineSeparator() + "Notes: " +
                        todaysEvents.get(i + 4) + System.lineSeparator() + "Dress Code: " +
                        todaysEvents.get(i + 5) + System.lineSeparator() + "Where: " +
                        todaysEvents.get(i + 6) + ", " + todaysEvents.get(i + 7) + ", " +
                        todaysEvents.get(i + 8) + " " + todaysEvents.get(i + 9) + 
                        System.lineSeparator() + "Attendees: " + attendees
                    ));
                    
                    
                    
                }
                
                i += 8; 
            }
                    
            h2.shutdown();
                
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
    } 
    
    @FXML
    private void home(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("CoordinatorHomepage.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void createEvent(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("CreateEvent.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void viewEvents(ActionEvent event) throws IOException {        
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("EventsScreen.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    
    @FXML
    private void adminFunctions(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("AdminFunctions.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void signOut(ActionEvent event) throws IOException {        
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
        
        // popup with successful logout message
        final Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("LogoutPopUp.fxml"));
        Scene popUpScene = new Scene(FXMLFramePopUp);
        popUpScene.getStylesheets().add(css);
        popup.setScene(popUpScene);
        popup.show();
    }
}
