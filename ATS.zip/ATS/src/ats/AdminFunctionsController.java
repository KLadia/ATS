package ats;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class AdminFunctionsController implements Initializable {
    
    @FXML
    private TextField first_name;
    
    @FXML
    private TextField last_name;
    
    @FXML
    private TextField UIN;
    
    @FXML
    private TextField email;
    
    @FXML
    private CheckBox civil;
    
    @FXML
    private CheckBox environmental;
    
    @FXML
    private CheckBox biomed;
    
    @FXML
    private CheckBox software;
    
    @FXML
    private CheckBox dual;
    
    @FXML
    private TextField catalog_year;
    
    @FXML
    private TextField grad_year;
    
    @FXML
    private TextArea biography;
    
    @FXML
    private Label status;
    
    @FXML
    private ComboBox ambassador_dropdown;
    
    @FXML
    private ComboBox event_dropdown;
    
    @FXML
    private TextField hours;
    
    @FXML
    private Accordion ambassador_list;
    
    @FXML
    private Label status_bottom;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        status.setText(""); // empty label place holder
        status_bottom.setText("");
        
        try {
            // add ambassadors to ambassador titlepane list
            DBManager h2 = new DBManager();
            
            ArrayList<String> ambassadorData = h2.getAmbassadorData();
            ArrayList<TitledPane> panes = new ArrayList<TitledPane>();
            
            for(int i = 0; i < ambassadorData.size(); i++) {
                                
                String uin = ambassadorData.get(i);
                
                if(!(i + 9 > ambassadorData.size())) {
                    
                    panes.add(new TitledPane(ambassadorData.get(i + 1) + " " + ambassadorData.get(i + 2),
                    new Label("UIN: " + uin + System.lineSeparator() +
                        "Email: " + ambassadorData.get(i + 3) + System.lineSeparator() +
                        "Major(s): " + ambassadorData.get(i + 4) + System.lineSeparator() +
                        "Catalog: " + ambassadorData.get(i + 5) + System.lineSeparator() +
                        "Graduation: " + ambassadorData.get(i + 6) + System.lineSeparator() +
                        "Biography: " + ambassadorData.get(i + 7) + System.lineSeparator() +
                        "Hours: " + ambassadorData.get(i + 8)
                    )));
                    
                }
                
                i += 8; // update to next ambassador in list
            }

            ambassador_list.getPanes().addAll(panes);
            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
        
        try {
            // add ambassadors to ambassador dropdown list
            DBManager h2 = new DBManager();
            
            ArrayList<String> ambassadorData = h2.getAmbassadorData();
            
            for(int i = 0; i < ambassadorData.size(); i++) {
                                                
                if(!(i + 9 > ambassadorData.size())) {
                    
                    ambassador_dropdown.getItems().addAll(ambassadorData.get(i + 1) + " " + ambassadorData.get(i + 2));
                }
                
                i += 8; // update to next ambassador in list
            }
            
            h2.shutdown();
                
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
        try {
            
            // add events to dropdown
            
            DBManager h2 = new DBManager();
            
            ArrayList<String> eventData = h2.getEventData();
            
            for(int i = 0; i < eventData.size(); i++) {
                                
                String id = eventData.get(i);
                
                if(!(i + 13 > eventData.size())) {
                    
                    event_dropdown.getItems().addAll(eventData.get(i + 1));
                    
                }
                
                i += 12; // update to next event in list
            }

            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }

    }
    
    @FXML
    private void addAmbassadorHours(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {
        
        // TODO, event logging for hours added
        // if hours < 0
        // Added X hours to NAME for EVENTNAME
        // otherwise
        // Removed Y hours from NAME for EVENTNAME
        
        if(ambassador_dropdown.getValue() == null) {
            status_bottom.setText("Please select an ambassador");
        }
        else if(hours.getText().equals("")) {
            status_bottom.setText("Please input number of service hours");
        }
        else {
            // tokenize ambassador name
            StringTokenizer st = new StringTokenizer(ambassador_dropdown.getValue().toString());
        
            String firstname = new String();
            String lastname = new String();
        
            while (st.hasMoreTokens()) {
                firstname = st.nextElement().toString();
                lastname = st.nextElement().toString();
            }
        
            DBManager h2 = new DBManager();
        
            String uin = h2.getAmbassadorUIN(firstname, lastname); // get selected student's UIN
            int current_hours = h2.getAmbassadorHours(uin); // the current hours they've done
            int added_hours = Integer.parseInt(hours.getText()); // get hour sto add from textfield
        
            h2.updateAmbassadorHours(uin, current_hours + added_hours); // add and update hours
            
            int current_logged = h2.getLogCount();
            if(added_hours < 0) { // taking away hours
                h2.updateLog(current_logged + 1, LoginScreenController.current_user +
                    " : Removed " + added_hours * (-1) + " hours from " + 
                    ambassador_dropdown.getValue().toString() + " total for " + 
                    event_dropdown.getValue().toString() + ".");
            }
            else { // adding hours
                h2.updateLog(current_logged + 1, LoginScreenController.current_user +
                    " : Added " + added_hours + " hours to " + 
                    ambassador_dropdown.getValue().toString() + " total for " + 
                    event_dropdown.getValue().toString() + ".");
            }
            
            status_bottom.setText("Hours added, refresh window to view changes");
            
            h2.shutdown();
            
        }

    }
    
    @FXML
    private void addAmbassador(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {
        
        boolean proceed = true;

        if(UIN.getText().length() != 9) { // check length of entered UIN
            status.setText("Invalid UIN");
            proceed = false; // cannot submit
        }
        else if(first_name.getText().startsWith(" ") 
                || first_name.getText().equals(null)) { // check for valid first name
            
            status.setText("Invalid first name");
            proceed = false; // cannot submit
        }
        else if(last_name.getText().startsWith(" ") 
                || last_name.getText().equals(null)) { // check for valid last name
            
            status.setText("Invalid last name");
            proceed = false; // cannot submit
        }
        else if(!civil.isSelected() && !software.isSelected() &&
                !biomed.isSelected() && !environmental.isSelected()) {
            
            // at least one box must box must be selected to choose major
            
            status.setText("Invalid major selection");
            proceed = false; // cannot submit
        }
        else if(!catalog_year.getText().startsWith("Fall ") && !catalog_year.getText().startsWith("Spring ")
                && !catalog_year.getText().startsWith("Summer ")) {
            
            // catalog year must start with semester of entry
            
            status.setText("Invalid catalog year");
            proceed = false; // cannot submit
        }
        else if(!grad_year.getText().startsWith("Fall ") && !grad_year.getText().startsWith("Spring ")
                && !grad_year.getText().startsWith("Summer ")) {
            
            // grad year must start with semester of entry
            
            status.setText("Invalid graduation year");
            proceed = false; // cannot submit
        }
        else if(biography.getText().length() <= 1) {
            status.setText("Invalid biography");
            proceed = false; // cannot submit
        }
        else if(biography.getText().length() > 300) { // check bio length            
            status.setText("Biography must be 300 characters or less");
            proceed = false; // cannot submit
        }
        
        if(proceed) { // we can now offically submit, input has been checked
            
            status.setText(""); // update label placeholder to hide error message
            
            DBManager h2 = new DBManager();
            
            if(civil.isSelected()) { // add ambassador into database with civil
                
                h2.insertAmbassador(UIN.getText(), first_name.getText(), last_name.getText(),
                    email.getText(), "Civil Engineering", catalog_year.getText(), grad_year.getText(),
                    biography.getText(), 0);
            }
            else if(software.isSelected()) { // add ambassador into database with software
                
                h2.insertAmbassador(UIN.getText(), first_name.getText(), last_name.getText(),
                    email.getText(), "Software Engineering", catalog_year.getText(), grad_year.getText(),
                    biography.getText(), 0);
            }
            else if(environmental.isSelected()) { // add ambassador into database with environmental
                
                h2.insertAmbassador(UIN.getText(), first_name.getText(), last_name.getText(),
                    email.getText(), "Environmental Engineering", catalog_year.getText(), grad_year.getText(),
                    biography.getText(), 0);
            }
            else if(biomed.isSelected()) { // add ambassador into database with biomed
                
                h2.insertAmbassador(UIN.getText(), first_name.getText(), last_name.getText(),
                    email.getText(), "Bioengineering", catalog_year.getText(), grad_year.getText(),
                    biography.getText(), 0);
            } 
            
            // @catkins: following blocks deal with selecting multiple majors
            // there's probably a better way to do this
            
            else if(civil.isSelected() && software.isSelected()) {
                // add ambassador into database with more than one major
                
                h2.insertAmbassador(UIN.getText(), first_name.getText(), last_name.getText(),
                    email.getText(), "Civil Engineering, Software Engineering", catalog_year.getText(), 
                    grad_year.getText(), biography.getText(), 0);
            }
            else if(civil.isSelected() && environmental.isSelected()) {
                // add ambassador into database with more than one major
                
                h2.insertAmbassador(UIN.getText(), first_name.getText(), last_name.getText(),
                    email.getText(), "Civil Engineering, Environmental Engineering", catalog_year.getText(), 
                    grad_year.getText(), biography.getText(), 0);
            }
            else if(civil.isSelected() && biomed.isSelected()) {
                // add ambassador into database with more than one major
                
                h2.insertAmbassador(UIN.getText(), first_name.getText(), last_name.getText(),
                    email.getText(), "Civil Engineering, Bioengineering", catalog_year.getText(), 
                    grad_year.getText(), biography.getText(), 0);
            }
            else if(biomed.isSelected() && software.isSelected()) {
                // add ambassador into database with more than one major
                
                h2.insertAmbassador(UIN.getText(), first_name.getText(), last_name.getText(),
                    email.getText(), "Bioengineering, Software Engineering", catalog_year.getText(), 
                    grad_year.getText(), biography.getText(), 0);
            }
            else if(biomed.isSelected() && environmental.isSelected()) {
                // add ambassador into database with more than one major
                
                h2.insertAmbassador(UIN.getText(), first_name.getText(), last_name.getText(),
                    email.getText(), "Bioengineering, Environmental Engineering", catalog_year.getText(), 
                    grad_year.getText(), biography.getText(), 0);
            }
            else if(software.isSelected() && environmental.isSelected()) {
                // add ambassador into database with more than one major
                
                h2.insertAmbassador(UIN.getText(), first_name.getText(), last_name.getText(),
                    email.getText(), "Software Engineering, Environmental Engineering", catalog_year.getText(), 
                    grad_year.getText(), biography.getText(), 0);
            }
            
            status.setText("Ambassador created, refresh window to view");
            
            h2.shutdown();
            
        }
    }
    
    // sidebar button event methods 
    @FXML
    private void home(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("CoordinatorHomepage.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void createEvent(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("CreateEvent.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void viewEvents(ActionEvent event) throws IOException {        
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("EventsScreen.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    
    @FXML
    private void adminFunctions(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("AdminFunctions.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void signOut(ActionEvent event) throws IOException {        
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
        
        // popup with successful logout message
        final Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("LogoutPopUp.fxml"));
        Scene popUpScene = new Scene(FXMLFramePopUp);
        popUpScene.getStylesheets().add(css);
        popup.setScene(popUpScene);
        popup.show();
    }
    // end sidebar button event methods
    
}
