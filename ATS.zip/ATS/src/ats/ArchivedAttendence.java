package ats;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ArchivedAttendence implements Initializable {
    
    @FXML
    private DatePicker from_date;
    
    @FXML
    private DatePicker to_date;
    
    @FXML
    private Label status;
    
    @FXML
    private VBox chart;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        status.setText("");
    }

    @FXML
    private void submit(ActionEvent event) throws IOException {
                
        if(from_date.getValue() == null || to_date.getValue() == null) {
            status.setText("Invalid date");
        }
        else {
            
            status.setText("");
            
            // clear any data that might have been there before
            chart.getChildren().clear();
                
            //defining the axes
            final CategoryAxis xAxis = new CategoryAxis();
            final NumberAxis yAxis = new NumberAxis();
        
            xAxis.setLabel("Event");
        
            //creating the chart
            final LineChart<String,Number> lineChart = new LineChart<String,Number>(xAxis,yAxis);
                
            lineChart.setTitle("Event Attendance");
        
            //defining a series
            XYChart.Series series = new XYChart.Series();
            XYChart.Series series2 = new XYChart.Series();
        
            series.setName("Off Campus");
            series2.setName("On Campus");
        
            String address = new String(); // for tracking on or off campus event
            String title = new String();
        
            try {
            
                DBManager h2 = new DBManager();
            
                ArrayList<String> eventData = h2.getEventsBetweenDate(from_date.getValue().toString(),
                    to_date.getValue().toString());
            
                for(int i = 0; i < eventData.size(); i++) {
                                
                    String id = eventData.get(i);
                
                    if(!(i + 13 > eventData.size())) {
                    
                        title = eventData.get(i + 1);
                        address = eventData.get(i + 8);
                    
                        if(address.contains("FGCU")) { // it's an on campus event
                            series.getData().add(new XYChart.Data(title, 
                                h2.countEventAttendees(id)));
                        }
                        else {
                            series2.getData().add(new XYChart.Data(title, 
                                h2.countEventAttendees(id)));
                        }
                    }
                
                    i += 12; // update to next ambassador in list
                }

                h2.shutdown();
            
            } catch (SQLException ex) { // catches for opening database connection
            } catch (ClassNotFoundException ex) {
            }
        
            lineChart.getData().addAll(series, series2);
            chart.getChildren().addAll(lineChart);
        }
        
    }    
    
}
