package ats;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


public class SystemFunctions implements Initializable {
    
    // for admin pop up
    public static boolean isAdminDelete = false;
    public static boolean isAdminModify = false;
    public static String admin_who;
    public static String admin_what;
    public static String admin_new;
    
    // for ambassador popup
    public static boolean isAmbassadorDelete = false;
    public static boolean isAmbassadorModify = false;
    public static String ambassador_who;
    public static String ambassador_what;
    public static String ambassador_new;
    
    // for event popup
    public static boolean isEventDelete = false;
    public static boolean isEventModify = false;
    public static boolean isEventAll = false;
    public static String event_who;
    public static String event_what;
    public static String event_new;
    
   
    // edit side elements (left)
    
    @FXML
    private ComboBox admin;
    
    @FXML
    private ComboBox admin_component;
    
    @FXML
    private RadioButton admin_delete;
    
    @FXML
    private RadioButton admin_modify;
    
    @FXML
    private TextField admin_value;
    
    @FXML
    private Label admin_status;
    
    @FXML
    private ComboBox events;
    
    @FXML
    private ComboBox event_component;
    
    @FXML
    private RadioButton event_delete;
    
    @FXML
    private RadioButton event_modify;
    
    @FXML
    private RadioButton event_add;
    
    @FXML
    private TextField event_value;
    
    @FXML
    private Label event_status;
    
    @FXML
    private ComboBox ambassador;
    
    @FXML
    private ComboBox ambassador_component;
    
    @FXML
    private RadioButton ambassador_delete;
    
    @FXML
    private RadioButton ambassador_modify;
    
    @FXML
    private RadioButton ambassador_add;
    
    @FXML
    private TextField ambassador_value;
    
    @FXML
    private Label ambassador_status;
    
    // log side elements (right)
    
    @FXML
    private Label ambassador_log;
    
    @FXML
    private Label event_log;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        ambassador_status.setText("");
        admin_status.setText("");
        event_status.setText("");
        
        // add event components to dropdown
        event_component.getItems().addAll("Title", "Date", "Start Time", "End Time",
            "Description", "Notes", "Dress Code", "City", "State", "Zip", "Attendees");
        
        try {
            
            // add events to dropdown
            
            DBManager h2 = new DBManager();
            
            ArrayList<String> eventData = h2.getEventData();
            
            for(int i = 0; i < eventData.size(); i++) {
                                
                String id = eventData.get(i);
                
                if(!(i + 13 > eventData.size())) {
                    
                    events.getItems().addAll(eventData.get(i + 1));
                    
                }
                
                i += 12; // update to next event in list
            }

            events.getItems().addAll("All Events");
            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
        // add admin components to dropdown
        admin_component.getItems().addAll("Password");
        
        try {
            
            // add admins to dropdown
            
            DBManager h2 = new DBManager();
            
            ArrayList<String> adminData = h2.getAdminData();
            
            for(int i = 0; i < adminData.size(); i++) {
                                                
                if(!(i + 2 > adminData.size())) {
                    
                    admin.getItems().addAll(adminData.get(i));
                }
                
                i += 1; // update to admin event in list
            }

            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
        
        // add ambassador components to drop down list
        ambassador_component.getItems().addAll("UIN", "First Name", "Last Name",
            "Email", "Major", "Entry Semester", "Grad Year", "Bio");
        
        try {
            // add ambassadors to ambassador dropdown list
            DBManager h2 = new DBManager();
            
            ArrayList<String> ambassadorData = h2.getAmbassadorData();
            
            for(int i = 0; i < ambassadorData.size(); i++) {
                                                
                if(!(i + 9 > ambassadorData.size())) {
                    
                    ambassador.getItems().addAll(ambassadorData.get(i) + ": " +
                        ambassadorData.get(i + 1) + " " + ambassadorData.get(i + 2));
                }
                
                i += 8; // update to next ambassador in list
            }
            
            h2.shutdown();
                
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
        try {
            // add logs to label
            DBManager h2 = new DBManager();
            
            ArrayList<String> logData = h2.getLogData();
            String store_logs = new String(); // used to set text of label
            
            for(int i = logData.size() - 1; i >= 0; i--) {
                
                if(!(i - 2 < 0)) {
                    store_logs += (logData.get(i) + System.lineSeparator());
                }
                
                i--;                    
            }
            
            ambassador_log.setText(store_logs);

            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
        try {
            // add logs to label
            DBManager h2 = new DBManager();
            
            ArrayList<String> logData = h2.getEventsLogData();
            String store_logs = new String(); // used to set text of label
            
            for(int i = logData.size() - 1; i >= 0; i--) {
                
                if(!(i - 2 < 0)) {
                    store_logs += (logData.get(i) + System.lineSeparator());
                }
                
                i--;                    
            }
            
            event_log.setText(store_logs);

            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
    }    
    
    @FXML
    private void editAmbassador(ActionEvent event) throws IOException {
        
        boolean proceed = true;
        
        if(ambassador.getSelectionModel().isEmpty()) {
            ambassador_status.setText("Please select an ambassador");
            proceed = false;
        }
        else if(ambassador_modify.isSelected() && ambassador_delete.isSelected()) {
            ambassador_status.setText("Please only choose one option (modify or delete)");
            proceed = false;
        }
        else if(!ambassador_modify.isSelected() && !ambassador_delete.isSelected()) {
            ambassador_status.setText("Please choose either modify or delete");
            proceed = false;
        }
        else if(ambassador_component.getSelectionModel().isEmpty() && ambassador_modify.isSelected()) {
            ambassador_status.setText("Please select a component to modify");
            proceed = false;
        }
        else if(ambassador_value.getText().isEmpty() && ambassador_modify.isSelected()) {
            ambassador_status.setText("Please enter a new value if modifying");
            proceed = false;
        }
        else if(!ambassador_value.getText().isEmpty() && ambassador_delete.isSelected()) {
            ambassador_status.setText("New value not needed when setting inactive");
            proceed = false;
        }
        else if(!ambassador_component.getSelectionModel().isEmpty() && ambassador_delete.isSelected()) {
            ambassador_status.setText("Component not needed when setting inactive");
            proceed = false;
        }
        
        try {
            
            DBManager h2 = new DBManager();
        
            if(proceed) {
        
                if(ambassador_delete.isSelected()) { // delete component
                    
                    isAmbassadorDelete = true;
                    ambassador_who = ambassador.getValue().toString();
                    
                    final Stage popup = new Stage();
                    popup.initModality(Modality.APPLICATION_MODAL);
                    Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("ModifyAmbassador.fxml"));
                    Scene popUpScene = new Scene(FXMLFramePopUp);
                    String css = ATS.class.getResource("CSS_PopUps.css").toExternalForm();
                    popUpScene.getStylesheets().add(css);
                    popup.setScene(popUpScene);
                    popup.show();
                    
                    // refresh system page after confirming
                    popup.setOnCloseRequest(new EventHandler<WindowEvent>() {
                        public void handle(WindowEvent we) {
                            try{
                                Parent FXMLFrame = FXMLLoader.load(getClass().getResource("SystemFunctions.fxml"));
                                Scene scene = new Scene(FXMLFrame);
                                String css = ATS.class.getResource("CSS.css").toExternalForm();
                                scene.getStylesheets().add(css);
                                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                                stage.setScene(scene);
                                stage.show();
                            } catch (IOException e) {
                                // catch message
                            }
                        }
                    });
                     
                }
                else if(ambassador_modify.isSelected()) { // add or modify
                    
                    isAmbassadorModify = true;
                    ambassador_who = ambassador.getValue().toString();
                    ambassador_what = ambassador_component.getValue().toString();
                    ambassador_new = ambassador_value.getText();
                    
                    final Stage popup = new Stage();
                    popup.initModality(Modality.APPLICATION_MODAL);
                    Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("ModifyAmbassador.fxml"));
                    Scene popUpScene = new Scene(FXMLFramePopUp);
                    String css = ATS.class.getResource("CSS_PopUps.css").toExternalForm();
                    popUpScene.getStylesheets().add(css);
                    popup.setScene(popUpScene);
                    popup.show();
                    
                    // refresh system page after confirming
                    popup.setOnCloseRequest(new EventHandler<WindowEvent>() {
                        public void handle(WindowEvent we) {
                            try{
                                Parent FXMLFrame = FXMLLoader.load(getClass().getResource("SystemFunctions.fxml"));
                                Scene scene = new Scene(FXMLFrame);
                                String css = ATS.class.getResource("CSS.css").toExternalForm();
                                scene.getStylesheets().add(css);
                                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                                stage.setScene(scene);
                                stage.show();
                            } catch (IOException e) {
                                // catch message
                            }
                        }
                    });
                    
                }
            
            }
            
            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
    }
    
    @FXML
    private void editEvent(ActionEvent event) throws IOException {
        
        boolean proceed = true;
        
        if(events.getSelectionModel().isEmpty()) {
            event_status.setText("Please select an event");
            proceed = false;
        }
        else if(event_modify.isSelected() && event_delete.isSelected()) {
            event_status.setText("Please only choose one option (modify or delete)");
            proceed = false;
        }
        else if(!event_modify.isSelected() && !event_delete.isSelected()) {
            event_status.setText("Please choose either modify or delete");
            proceed = false;
        }
        else if(event_component.getSelectionModel().isEmpty() && event_modify.isSelected()) {
            event_status.setText("Please select a component to modify");
            proceed = false;
        }
        else if(event_value.getText().isEmpty() && event_modify.isSelected()) {
            event_status.setText("Please enter a new value if modifying");
            proceed = false;
        }
        else if(!event_value.getText().isEmpty() && event_delete.isSelected()) {
            event_status.setText("New value not needed when archiving");
            proceed = false;
        }
        else if(!event_component.getSelectionModel().isEmpty() && event_delete.isSelected()) {
            event_status.setText("Component not needed when archiving");
            proceed = false;
        }
        else if(!event_delete.isSelected() && event_component.getValue().equals("All Events")
            && event_modify.isSelected()) {
                event_status.setText("Cannot modify all events at once");
                proceed = false;
        }
        
        try {
            
            DBManager h2 = new DBManager();
        
            if(proceed) {
        
                if(event_delete.isSelected()) { // delete component
                    
                    isEventDelete = true;
                    event_who = events.getValue().toString();
                    
                    final Stage popup = new Stage();
                    popup.initModality(Modality.APPLICATION_MODAL);
                    Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("ModifyEvent.fxml"));
                    Scene popUpScene = new Scene(FXMLFramePopUp);
                    String css = ATS.class.getResource("CSS_PopUps.css").toExternalForm();
                    popUpScene.getStylesheets().add(css);
                    popup.setScene(popUpScene);
                    popup.show();
                    
                    // refresh system page after confirming
                    popup.setOnCloseRequest(new EventHandler<WindowEvent>() {
                        public void handle(WindowEvent we) {
                            try{
                                Parent FXMLFrame = FXMLLoader.load(getClass().getResource("SystemFunctions.fxml"));
                                Scene scene = new Scene(FXMLFrame);
                                String css = ATS.class.getResource("CSS.css").toExternalForm();
                                scene.getStylesheets().add(css);
                                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                                stage.setScene(scene);
                                stage.show();
                            } catch (IOException e) {
                                // catch message
                            }
                        }
                    });
                     
                }
                else if(event_modify.isSelected()) { // add or modify
                    
                    isEventModify = true;
                    event_who = events.getValue().toString();
                    event_what = event_component.getValue().toString();
                    event_new = event_value.getText();
                    
                    final Stage popup = new Stage();
                    popup.initModality(Modality.APPLICATION_MODAL);
                    Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("ModifyEvent.fxml"));
                    Scene popUpScene = new Scene(FXMLFramePopUp);
                    String css = ATS.class.getResource("CSS_PopUps.css").toExternalForm();
                    popUpScene.getStylesheets().add(css);
                    popup.setScene(popUpScene);
                    popup.show();
                    
                    // refresh system page after confirming
                    popup.setOnCloseRequest(new EventHandler<WindowEvent>() {
                        public void handle(WindowEvent we) {
                            try{
                                Parent FXMLFrame = FXMLLoader.load(getClass().getResource("SystemFunctions.fxml"));
                                Scene scene = new Scene(FXMLFrame);
                                String css = ATS.class.getResource("CSS.css").toExternalForm();
                                scene.getStylesheets().add(css);
                                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                                stage.setScene(scene);
                                stage.show();
                            } catch (IOException e) {
                                // catch message
                            }
                        }
                    });
                    
                }
            
            }
            
            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
    }
    
    @FXML
    private void editAdmin(ActionEvent event) throws IOException {
        
        boolean proceed = true;
        
        if(admin.getSelectionModel().isEmpty()) {
            admin_status.setText("Please select a user");
            proceed = false;
        }
        else if(admin_modify.isSelected() && admin_delete.isSelected()) {
            admin_status.setText("Please only choose one option (modify or delete)");
            proceed = false;
        }
        else if(!admin_modify.isSelected() && !admin_delete.isSelected()) {
            admin_status.setText("Please choose either modify or delete");
            proceed = false;
        }
        else if(admin_component.getSelectionModel().isEmpty() && admin_modify.isSelected()) {
            admin_status.setText("Please select a component to modify");
            proceed = false;
        }
        else if(admin_value.getText().isEmpty() && admin_modify.isSelected()) {
            admin_status.setText("Please enter a new value if modifying");
            proceed = false;
        }
        else if(!admin_value.getText().isEmpty() && admin_delete.isSelected()) {
            admin_status.setText("New value not needed when deleting");
            proceed = false;
        }
        else if(!admin_component.getSelectionModel().isEmpty() && admin_delete.isSelected()) {
            admin_status.setText("Component not needed when deleting");
            proceed = false;
        }
        
        try {
            
            DBManager h2 = new DBManager();
        
            if(proceed) {
        
                if(admin_delete.isSelected()) { // delete component
                    
                    isAdminDelete = true;
                    admin_who = admin.getValue().toString();
                    
                    final Stage popup = new Stage();
                    popup.initModality(Modality.APPLICATION_MODAL);
                    Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("ModifyAdmin.fxml"));
                    Scene popUpScene = new Scene(FXMLFramePopUp);
                    String css = ATS.class.getResource("CSS_PopUps.css").toExternalForm();
                    popUpScene.getStylesheets().add(css);
                    popup.setScene(popUpScene);
                    popup.show();
                    
                    // refresh system page after confirming
                    popup.setOnCloseRequest(new EventHandler<WindowEvent>() {
                        public void handle(WindowEvent we) {
                            try{
                                Parent FXMLFrame = FXMLLoader.load(getClass().getResource("SystemFunctions.fxml"));
                                Scene scene = new Scene(FXMLFrame);
                                String css = ATS.class.getResource("CSS.css").toExternalForm();
                                scene.getStylesheets().add(css);
                                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                                stage.setScene(scene);
                                stage.show();
                            } catch (IOException e) {
                                // catch message
                            }
                        }
                    });
                    
                }
                else if(admin_modify.isSelected()) { // add or modify
                    
                    isAdminModify = true;
                    admin_who = admin.getValue().toString();
                    admin_what = admin_component.getValue().toString();
                    admin_new = admin_value.getText();
                    
                    final Stage popup = new Stage();
                    popup.initModality(Modality.APPLICATION_MODAL);
                    Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("ModifyAdmin.fxml"));
                    Scene popUpScene = new Scene(FXMLFramePopUp);
                    String css = ATS.class.getResource("CSS_PopUps.css").toExternalForm();
                    popUpScene.getStylesheets().add(css);
                    popup.setScene(popUpScene);
                    popup.show();
                    
                    // refresh system page after confirming
                    popup.setOnCloseRequest(new EventHandler<WindowEvent>() {
                        public void handle(WindowEvent we) {
                            try{
                                Parent FXMLFrame = FXMLLoader.load(getClass().getResource("SystemFunctions.fxml"));
                                Scene scene = new Scene(FXMLFrame);
                                String css = ATS.class.getResource("CSS.css").toExternalForm();
                                scene.getStylesheets().add(css);
                                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                                stage.setScene(scene);
                                stage.show();
                            } catch (IOException e) {
                                // catch message
                            }
                        }
                    });
                   
                }
            
            }
            
            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
    }
    
    @FXML
    private void clearAmbassadaorLog(ActionEvent event) throws IOException {
        final Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("ClearAmbassadorLog.fxml"));
        Scene popUpScene = new Scene(FXMLFramePopUp);
        String css = ATS.class.getResource("CSS_PopUps.css").toExternalForm();
        popUpScene.getStylesheets().add(css);
        popup.setScene(popUpScene);
        popup.show();
        
        // refresh system page after confirming
        popup.setOnCloseRequest(new EventHandler<WindowEvent>() {
            public void handle(WindowEvent we) {
                try{
                    Parent FXMLFrame = FXMLLoader.load(getClass().getResource("SystemFunctions.fxml"));
                    Scene scene = new Scene(FXMLFrame);
                    String css = ATS.class.getResource("CSS.css").toExternalForm();
                    scene.getStylesheets().add(css);
                    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    stage.setScene(scene);
                    stage.show();
                } catch (IOException e) {
                    // catch message
                }
            }
        });
    }
    
    @FXML
    private void clearEventLog(ActionEvent event) throws IOException {
        final Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("ClearEventsLog.fxml"));
        Scene popUpScene = new Scene(FXMLFramePopUp);
        String css = ATS.class.getResource("CSS_PopUps.css").toExternalForm();
        popUpScene.getStylesheets().add(css);
        popup.setScene(popUpScene);
        popup.show();
        
        // refresh system page after confirming
        popup.setOnCloseRequest(new EventHandler<WindowEvent>() {
            public void handle(WindowEvent we) {
                try{
                    Parent FXMLFrame = FXMLLoader.load(getClass().getResource("SystemFunctions.fxml"));
                    Scene scene = new Scene(FXMLFrame);
                    String css = ATS.class.getResource("CSS.css").toExternalForm();
                    scene.getStylesheets().add(css);
                    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    stage.setScene(scene);
                    stage.show();
                } catch (IOException e) {
                    // catch message
                }
            }
        });
    }
    
    // sidebar buttons
    @FXML
    private void home(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void createEvent(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("EventManager.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void viewEvents(ActionEvent event) throws IOException {        
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("SystemFunctions.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    
    @FXML
    private void adminFunctions(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("AmbassadorManager.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void signOut(ActionEvent event) throws IOException {        
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
        
        // popup with successful logout message
        final Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("Logout.fxml"));
        Scene popUpScene = new Scene(FXMLFramePopUp);
        popUpScene.getStylesheets().add(css);
        popup.setScene(popUpScene);
        popup.show();
    }
}
