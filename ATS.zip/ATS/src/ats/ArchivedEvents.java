package ats;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Accordion;
import javafx.scene.control.Label;
import javafx.scene.control.TitledPane;

public class ArchivedEvents implements Initializable {

    @FXML
    private Accordion event_list;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            
            DBManager h2 = new DBManager();
            
            ArrayList<String> eventData = h2.getEventDataArchived();
            ArrayList<TitledPane> panes = new ArrayList<TitledPane>();
            
            for(int i = 0; i < eventData.size(); i++) {
                
                String id = eventData.get(i);
                
                if(!(i + 10 > eventData.size())) {
                    
                    panes.add(new TitledPane(eventData.get(i + 1),
                    new Label("Date: " + eventData.get(i + 2) + System.lineSeparator() +
                        "Start Time: " + eventData.get(i + 3) + System.lineSeparator() +
                        "End Time: " + eventData.get(i + 4) + System.lineSeparator() +
                        "Description: " + eventData.get(i + 5) + System.lineSeparator() +
                        "Notes: " + eventData.get(i + 6) + System.lineSeparator() +
                        "Dress Code: " + eventData.get(i + 7) + System.lineSeparator() +
                        "Location: " + eventData.get(i + 8) + System.lineSeparator() + 
                        "                 " + eventData.get(i + 9) + ", " + 
                        eventData.get(i + 10) + " " + System.lineSeparator() + 
                        "Attendees: " + h2.getEventAttendees(id))
                    ));
                    
                }
                
                i += 11; // update to next ambassador in list
                
            }

            event_list.getPanes().addAll(panes);
            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
    }    
    
}
