package ats;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.Modality;


public class LoginScreenController implements Initializable {
    
    public static String current_user;
    
    @FXML
    private TextField username;
    
    @FXML
    private TextField password;
    
    @FXML
    private Label incorrect_login;
    
    @FXML
    private Label total_ambassadors;
    
    @FXML
    private Label total_hours;
            
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        incorrect_login.setText(""); // empty label placeholders
        
        try {
            DBManager h2 = new DBManager(); // open database connection
            
            total_ambassadors.setText(Integer.toString(h2.getTotalAmbassadors()));
            total_hours.setText(Integer.toString(h2.getTotalHours()));
            
            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
    }    
    
    @FXML
    private void login(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {
        
        DBManager h2 = new DBManager();
        
        ArrayList<String> adminData = h2.getAdminData();
                
        for(int i = 0; i < adminData.size(); i++) {
                        
            if(username.getText().equals(adminData.get(i)) && password.getText().equals(adminData.get(i + 1))) {
                
                current_user = username.getText(); // to keep track of who is logged in
                
                Parent FXMLFrame = FXMLLoader.load(getClass().getResource("CoordinatorHomepage.fxml"));
                Scene scene = new Scene(FXMLFrame);
                String css = ATS.class.getResource("CSS.css").toExternalForm();
                scene.getStylesheets().add(css);
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(scene);
                stage.show();
            }
            else {
                incorrect_login.setText("Incorrect username or password");
            }
        }
        
        h2.shutdown();
    }
    
    @FXML
    private void completeIntakeApplication(ActionEvent event) throws IOException {
        final Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("IntakeApplication.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        popup.setScene(scene);
        popup.show();
    }
    
    @FXML
    private void pullHours(ActionEvent event) throws IOException {
        final Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("PullLog.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        popup.setScene(scene);
        popup.show();
    }
    
    @FXML
    private void pullEvents(ActionEvent event) throws IOException {
        final Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("PullEvents.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        popup.setScene(scene);
        popup.show();
    }
    
}
