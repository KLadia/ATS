package ats;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;


public class ClearEventsLog implements Initializable {

    @FXML
    private Label header;
    
    @FXML
    private Label info;
    
    @FXML
    private TextField username;
    
    @FXML
    private TextField password;
    
    @FXML
    private Label status;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        status.setText("");
    }

    @FXML
    private void confirm(ActionEvent event) throws IOException {
        
        boolean proceed = true;
        
        if(!(username.getText().equals(Homepage.current_user)) || 
            !(password.getText().equals(Homepage.current_password))) {
            
            proceed = false;
            status.setText("Incorrect username or password");
        }
        
        if(proceed) {
            try {
            
            DBManager h2 = new DBManager();
            
            h2.clearEventsLog();
            status.setText("Log cleared, close window to view changes");
            
            h2.shutdown();
            
            } catch (SQLException ex) { // catches for opening database connection
            } catch (ClassNotFoundException ex) {
            }
        }
    }    
    
}
