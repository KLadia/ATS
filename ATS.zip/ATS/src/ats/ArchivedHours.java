/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ats;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Side;
import javafx.scene.chart.PieChart;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author chelseaatkins
 */
public class ArchivedHours implements Initializable {

    @FXML
    private VBox hold_chart;
    
    @FXML
    private DatePicker from_date;
    
    @FXML
    private DatePicker to_date;
    
    @FXML
    private Label status;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        status.setText("");
    }
    
    @FXML
    private void submit(ActionEvent event) throws IOException {
                
        if(from_date.getValue() == null || to_date.getValue() == null) {
            status.setText("Invalid date");
        }
        else {
            
            status.setText("");
            
            // clear any data that might have been there before
            hold_chart.getChildren().clear();
            
            // id, major, date, hours
            ObservableList<PieChart.Data> pieChartData;
        
            try {
            
                DBManager h2 = new DBManager();
                
                pieChartData =
                    FXCollections.observableArrayList(
                    new PieChart.Data("Software", h2.getArchivedHoursByMajor(
                        "Software Engineering", from_date.getValue().toString(),
                        to_date.getValue().toString())
                    ),
                    new PieChart.Data("Environmental", h2.getArchivedHoursByMajor(
                        "Environmental Engineering", from_date.getValue().toString(),
                        to_date.getValue().toString())
                    ),
                    new PieChart.Data("Bio", h2.getArchivedHoursByMajor(
                        "Bioengineering", from_date.getValue().toString(),
                        to_date.getValue().toString())
                    ),
                    new PieChart.Data("Civil", h2.getArchivedHoursByMajor(
                        "Civil Engineering", from_date.getValue().toString(),
                        to_date.getValue().toString())
                    )
                );
                
            
                h2.shutdown();
            
                final PieChart chart = new PieChart(pieChartData);
            
                pieChartData.forEach(
                    data -> data.nameProperty().bind(
                        Bindings.concat(
                            data.getName(), System.lineSeparator(), data.pieValueProperty(), " hours"
                        )
                    )
                );
            
                // chart.setLegendVisible(false);
            
                chart.setLegendSide(Side.LEFT);
                chart.setLabelsVisible(false);
            
                chart.setTitle("Ambassador Hours by Major");
                hold_chart.getChildren().addAll(chart);
            
            } catch (SQLException ex) { // catches for opening database connection
            } catch (ClassNotFoundException ex) {
            }
        
        }
    }
}
