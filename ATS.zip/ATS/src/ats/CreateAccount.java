package ats;

import static ats.Homepage.current_password;
import static ats.Homepage.current_user;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CreateAccount implements Initializable {
    
    @FXML
    private TextField username;
    
    @FXML
    private TextField confirm_username;
    
    @FXML
    private TextField password;
    
    @FXML
    private TextField confirm_password;
    
    @FXML
    private TextField auth_username;
    
    @FXML
    private TextField auth_password;
    
    @FXML
    private Label status;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        status.setText("");
    }
    
    @FXML
    private void submit(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {
        
        boolean proceed = true;
        boolean user_exists = false;
        boolean authorized_login = false;
        
        DBManager h2 = new DBManager();
        
        ArrayList<String> adminData = h2.getAdminData();
        
        if(password.getText().equals("") || password.getText().startsWith(" ")) {
            status.setText("Invalid new password");
            proceed = false;
        }
        else if(username.getText().equals("") || username.getText().startsWith(" ")) {
            status.setText("Invalid new username");
            proceed = false;
        }
        else if(!confirm_username.getText().equals(username.getText())) {
            status.setText("Usernames do not match");
            proceed = false;
        }
        else if(!confirm_password.getText().equals(password.getText())) {
            status.setText("Passwords do not match");
            proceed = false;
        }
        else if(proceed) { // unique username
            
            for(int i = 0; i < adminData.size(); i++) {
                if(username.getText().equals(adminData.get(i))) {
                    status.setText("User already exists");
                    user_exists = true;
                }
                i++; // iterate to next username
            }
            
        }
        
        if(user_exists) {
            status.setText("User already exists");
            proceed = false;
        }      
        
        for(int i = 0; i < adminData.size(); i++) {
            
            if(auth_username.getText().equals(adminData.get(i)) && auth_password.getText().equals(adminData.get(i + 1))
                && proceed) {
                    
                String load_username = username.getText();
                String load_password = password.getText();
            
                h2.insertAdmin(load_username, load_password);
                status.setText("Account created, close window to login with credentials");
                
                authorized_login = true;
            }
            else if(proceed && !authorized_login) {
                status.setText("Incorrect username or password");
            }
            
        }
        
        h2.shutdown();
    }
    
}
