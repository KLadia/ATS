package ats;

import java.io.IOException;
import java.sql.SQLException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author chelseaatkins
 */
public class ATS extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
        Scene scene = new Scene(root);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
        
        //DBH2Manager h2 = new DBH2Manager();
    }

    public static void main(String[] args) throws IOException, SQLException, ClassNotFoundException {
        
        launch(args);
        
        DBManager h2 = new DBManager();
        
        h2.insertAdmin("jnrose", "one");
        h2.insertAdmin("lzidek", "two");
        
        h2.shutdown();
                
    }
    
}
