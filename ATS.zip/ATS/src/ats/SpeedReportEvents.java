package ats;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class SpeedReportEvents implements Initializable {

    @FXML
    private Label log_info;
    
    @FXML
    private VBox hold_chart;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            // add logs to label
            DBManager h2 = new DBManager();
            
            ArrayList<String> logData = h2.getEventsLogData();
            String store_logs = new String(); // used to set text of label
            
            for(int i = logData.size() - 1; i >= 0; i--) {
                
                if(!(i - 2 < 0)) {
                    store_logs += (logData.get(i) + System.lineSeparator());
                }
                
                i--;                    
            }
            
            log_info.setText(store_logs);

            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
        // for line chart
        
        //defining the axes
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        
        xAxis.setLabel("Event");
        
        //creating the chart
        final LineChart<String,Number> lineChart = new LineChart<String,Number>(xAxis,yAxis);
                
        lineChart.setTitle("Event Attendance");
        
        //defining a series
        XYChart.Series series = new XYChart.Series();
        XYChart.Series series2 = new XYChart.Series();
        
        series.setName("Off Campus");
        series2.setName("On Campus");
        
        String address = new String(); // for tracking on or off campus event
        String title = new String();
        
        try {
            
            DBManager h2 = new DBManager();
            
            ArrayList<String> eventData = h2.getEventData();
            
            for(int i = 0; i < eventData.size(); i++) {
                                
                String id = eventData.get(i);
                
                if(!(i + 13 > eventData.size())) {
                    
                    title = eventData.get(i + 1);
                    address = eventData.get(i + 8);
                    
                    if(address.contains("FGCU")) { // it's an on campus event
                        series.getData().add(new XYChart.Data(title, 
                            h2.countEventAttendees(id)));
                    }
                    else {
                        series2.getData().add(new XYChart.Data(title, 
                            h2.countEventAttendees(id)));
                    }
                    
                }
                
                i += 12; // update to next ambassador in list
            }

            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
        lineChart.getData().addAll(series, series2);
        hold_chart.getChildren().addAll(lineChart);
        
        
    }    
    
}
