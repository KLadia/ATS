package ats;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ModifyAmbassador implements Initializable {

    @FXML
    private Label header;
    
    @FXML
    private Label info;
    
    @FXML
    private TextField username;
    
    @FXML
    private TextField password;
    
    @FXML
    private Label status;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        status.setText("");
    }
    
    @FXML
    private void confirm(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {
        
        boolean proceed = true;
                
        if(!(username.getText().equals(Homepage.current_user)) || 
            !(password.getText().equals(Homepage.current_password))) {
            
            proceed = false;
            status.setText("Incorrect username or password");
        }
                
        if(proceed) {
            
            String ambassador = SystemFunctions.ambassador_who;
            String ambassador_uin = ambassador.substring(0, Math.min(ambassador.length(), 9));
            
            String component = SystemFunctions.ambassador_what;
            String new_value = SystemFunctions.ambassador_new;
            
            if(SystemFunctions.isAmbassadorDelete) { // archiving ambassador
                try {
                    DBManager h2 = new DBManager();
                    
                    h2.deleteAmbassador(ambassador_uin);
                    status.setText("Ambassador archived, close window to view changes");
                    
                    h2.shutdown();
                    
                } catch (SQLException ex) { // catches for opening database connection
                } catch (ClassNotFoundException ex) {
                }
            }
            else if(SystemFunctions.isAmbassadorModify) { // modifying ambassador
                
                // ambassador components
                // ambassador_component.getItems().addAll("UIN", "First Name", "Last Name",
                // "Email", "Major", "Entry Semester", "Grad Year", "Bio");
                
                if(component.equals("UIN")) {
                    component = "uin";
                    if(new_value.length() != 9) {
                        status.setText("UIN must be nine digits long, close window and resubmit");
                    }
                    else {
                        try {
                            DBManager h2 = new DBManager();
                        
                            h2.updateAmbassadorComponent(ambassador_uin, component, new_value); 
                            status.setText("Component changed, close window to view changes");
                    
                            h2.shutdown();
                            
                        } catch (SQLException ex) { // catches for opening database connection
                        } catch (ClassNotFoundException ex) {
                        }
                    }
                }
                else if(component.equals("First Name")) {
                    component = "firstname";
                    try {
                        DBManager h2 = new DBManager();
                        
                        h2.updateAmbassadorComponent(ambassador_uin, component, new_value); 
                        status.setText("Component changed, close window to view changes");
                    
                        h2.shutdown();
                            
                    } catch (SQLException ex) { // catches for opening database connection
                    } catch (ClassNotFoundException ex) {
                    }
                }
                else if(component.equals("Last Name")) {
                    component = "lastname";
                    try {
                        DBManager h2 = new DBManager();
                        
                        h2.updateAmbassadorComponent(ambassador_uin, component, new_value); 
                        status.setText("Component changed, close window to view changes");
                    
                        h2.shutdown();
                            
                    } catch (SQLException ex) { // catches for opening database connection
                    } catch (ClassNotFoundException ex) {
                    }
                }
                else if(component.equals("Email")) {
                    component = "email";
                    try {
                        DBManager h2 = new DBManager();
                        
                        h2.updateAmbassadorComponent(ambassador_uin, component, new_value); 
                        status.setText("Component changed, close window to view changes");
                    
                        h2.shutdown();
                            
                    } catch (SQLException ex) { // catches for opening database connection
                    } catch (ClassNotFoundException ex) {
                    }
                }
                else if(component.equals("Major")) {
                    component = "major";
                    try {
                        DBManager h2 = new DBManager();
                        
                        h2.updateAmbassadorComponent(ambassador_uin, component, new_value); 
                        status.setText("Component changed, close window to view changes");
                    
                        h2.shutdown();
                            
                    } catch (SQLException ex) { // catches for opening database connection
                    } catch (ClassNotFoundException ex) {
                    }
                }
                else if(component.equals("Entry Semester")) {
                    component = "catalog";
                    try {
                        DBManager h2 = new DBManager();
                        
                        h2.updateAmbassadorComponent(ambassador_uin, component, new_value); 
                        status.setText("Component changed, close window to view changes");
                    
                        h2.shutdown();
                            
                    } catch (SQLException ex) { // catches for opening database connection
                    } catch (ClassNotFoundException ex) {
                    }
                }
                else if(component.equals("Grad Year")) {
                    component = "grad";
                    try {
                        DBManager h2 = new DBManager();
                        
                        h2.updateAmbassadorComponent(ambassador_uin, component, new_value); 
                        status.setText("Component changed, close window to view changes");
                    
                        h2.shutdown();
                            
                    } catch (SQLException ex) { // catches for opening database connection
                    } catch (ClassNotFoundException ex) {
                    }
                }
                else if(component.equals("Bio")) {
                    component = "bio";
                    try {
                        DBManager h2 = new DBManager();
                        
                        h2.updateAmbassadorComponent(ambassador_uin, component, new_value); 
                        status.setText("Component changed, close window to view changes");
                    
                        h2.shutdown();
                            
                    } catch (SQLException ex) { // catches for opening database connection
                    } catch (ClassNotFoundException ex) {
                    }
                }
            }
        }  
    }
}
