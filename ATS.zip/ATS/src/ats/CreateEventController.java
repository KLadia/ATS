package ats;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class CreateEventController implements Initializable {
    
    @FXML
    private TextField title;
    
    @FXML
    private DatePicker date;
    
    @FXML
    private TextField from;
    
    @FXML
    private TextField until;
    
    @FXML
    private TextArea description;
    
    @FXML
    private TextArea notes;
    
    @FXML
    private ComboBox dress_code;
    
    @FXML
    private RadioButton on_campus;
    
    @FXML
    private RadioButton off_campus;
    
    @FXML
    private TextField address;
    
    @FXML
    private TextField city;
    
    @FXML
    private TextField state;
    
    @FXML
    private TextField zip;
    
    @FXML
    private Label status;
    
    @FXML
    private RadioButton repeat_yes;
    
    @FXML
    private RadioButton repeat_no;
    
    @FXML
    private Accordion event_list;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        status.setText(""); // empty label placeholders
        
        // populate dress code dropdown menu
        dress_code.getItems().addAll("Casual", "Business Casual", "Business Smart", "Black Tie");
        
        try {
            
            // ID TITLE DATE START UNTIL DESCRIPTION NOTES DRESS_CODE ADDRESS CITY STATE ZIP  
            // add ambassadors to ambassador dropdown list
            
            DBManager h2 = new DBManager();
            
            ArrayList<String> eventData = h2.getEventData();
            ArrayList<TitledPane> panes = new ArrayList<TitledPane>();
            
            for(int i = 0; i < eventData.size(); i++) {
                                
                String id = eventData.get(i);
                
                if(!(i + 13 > eventData.size())) {
                    
                    panes.add(new TitledPane(eventData.get(i + 1),
                    new Label("Date: " + eventData.get(i + 2) + System.lineSeparator() +
                        "Start Time: " + eventData.get(i + 3) + System.lineSeparator() +
                        "End Time: " + eventData.get(i + 4) + System.lineSeparator() +
                        "Description: " + eventData.get(i + 5) + System.lineSeparator() +
                        "Notes: " + eventData.get(i + 6) + System.lineSeparator() +
                        "Dress Code: " + eventData.get(i + 7) + System.lineSeparator() +
                        "Location: " + eventData.get(i + 8) + System.lineSeparator() + 
                            "                 " + 
                            eventData.get(i + 9) + ", " + eventData.get(i + 10) + " " + 
                            eventData.get(i + 11) + System.lineSeparator() +
                        "Attendees: " + h2.getEventAttendees(id)
                    )));
                    
                }
                
                i += 12; // update to next ambassador in list
            }

            event_list.getPanes().addAll(panes);
            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
    }    
    
    @FXML
    private void submitEvent(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {
        
        boolean proceed = true;
        
        if(title.getText().startsWith(" ") || title.getText().equals("")) {
            status.setText("Invalid event title");
            proceed = false; // invalid entry cannot be loaded to database
        }
        else if(description.getText().equals("")) {
            
            status.setText("Please enter an event description");
            proceed = false; // invalid entry cannot be loaded to database
        }
        else if(description.getText().length() > 500) {
            
            status.setText("Descriptions should be under 500 characters");
            proceed = false; // invalid entry cannot be loaded to database
        }
        else if(notes.getText().equals("")) {
            status.setText("If no notes are needed, please enter 'N/A'");
            proceed = false; // invalid entry cannot be loaded to database
        }
        else if((address.getText().startsWith(" ") || address.getText().equals(""))
                && off_campus.isSelected()) {
            
            status.setText("Please enter a valid address");
            proceed = false; // invalid entry cannot be loaded to database
        }
        else if((address.getText().startsWith(" ") || address.getText().equals(""))
                && on_campus.isSelected()) {
            
            status.setText("Enter location in the address bar (ex. Holmes Hall 147)");
            proceed = false; // invalid entry cannot be loaded to database
        }
        else if(!(on_campus.isSelected()) && !(off_campus.isSelected())) {
            
            status.setText("Event must have a location, on campus events require area or room number");
            proceed = false; // invalid entry cannot be loaded to database
        }
        else if(on_campus.isSelected() && off_campus.isSelected()) {
            
            status.setText("Invalid location");
            proceed = false; // invalid entry cannot be loaded to database
        }
        else if((city.getText().startsWith(" ") || city.getText().equals(""))
                && off_campus.isSelected()) {
            
            status.setText("Invalid city");
            proceed = false; // invalid entry cannot be loaded to database
        }
        else if((state.getText().startsWith(" ") || state.getText().equals(""))
                && off_campus.isSelected()) {
            
            status.setText("Invalid state");
            proceed = false; // invalid entry cannot be loaded to database
        }
        else if((zip.getText().startsWith(" ") || zip.getText().equals(""))
                && off_campus.isSelected()) {
            
            status.setText("Invalid zip code");
            proceed = false; // invalid entry cannot be loaded to database
        }
        else if(from.getText().startsWith(" ") || from.getText().equals("") ||
                (!(from.getText().contains("AM")) && !(from.getText().contains("PM")))) {
            
            status.setText("Invalid start time");
            proceed = false; // invalid entry cannot be loaded to database
        }
        else if(until.getText().startsWith(" ") || until.getText().equals("") ||
                (!(until.getText().contains("AM")) && !(until.getText().contains("PM")))) {
            
            status.setText("Invalid end time");
            proceed = false; // invalid entry cannot be loaded to database
        }
        else if(repeat_yes.isSelected()) {
            
            // process for repeating event
            // show repeating event pop up
            // on what days does this repeat
            
            proceed = false;
        }
        
        
        // by the time we get here, we know whether or not it's okay to load into database
        if(proceed) { // okay to add to database
            
            DBManager h2 = new DBManager(); // open database connection
                        
            int new_event_id = h2.getEventCount() + 1; // create the new event's id
            
            h2.insertEvent(new_event_id, title.getText(), date.getValue().toString(), from.getText(),
                until.getText(), description.getText(), notes.getText(), dress_code.getValue().toString(),
                address.getText(), city.getText(), state.getText(), zip.getText(), null);
            
            h2.shutdown(); // close database connection
            
            status.setText("Event created, refresh window to view");
            
        }
    }
    
    @FXML
    private void home(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("CoordinatorHomepage.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void createEvent(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("CreateEvent.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void viewEvents(ActionEvent event) throws IOException {        
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("EventsScreen.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    
    @FXML
    private void adminFunctions(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("AdminFunctions.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void signOut(ActionEvent event) throws IOException {        
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
        
        // popup with successful logout message
        final Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("LogoutPopUp.fxml"));
        Scene popUpScene = new Scene(FXMLFramePopUp);
        popUpScene.getStylesheets().add(css);
        popup.setScene(popUpScene);
        popup.show();
    }
}
