package ats;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Side;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class SpeedReportHours implements Initializable {
    
    @FXML
    private Label log_info;
    
    @FXML
    private VBox hold_chart;
            
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        try {
            // add logs to label
            DBManager h2 = new DBManager();
            
            ArrayList<String> logData = h2.getLogData();
            String store_logs = new String(); // used to set text of label
            
            for(int i = logData.size() - 1; i >= 0; i--) {
                
                if(!(i - 2 < 0)) {
                    store_logs += (logData.get(i) + System.lineSeparator());
                }
                
                i--;                    
            }
            
            log_info.setText(store_logs);

            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
        // ambassadors hours by major pie chart
               
        ObservableList<PieChart.Data> pieChartData;
        
        try {
            
            DBManager h2 = new DBManager();
            
            pieChartData =
                FXCollections.observableArrayList(
                new PieChart.Data("Software", h2.getHoursByMajor("Software Engineering")),
                new PieChart.Data("Environmental", h2.getHoursByMajor("Environmental Engineering")),
                new PieChart.Data("Bio", h2.getHoursByMajor("Bioengineering")),
                new PieChart.Data("Civil", h2.getHoursByMajor("Civil Engineering"))
            );
            
            h2.shutdown();
            
            final PieChart chart = new PieChart(pieChartData);
            
            pieChartData.forEach(
                data -> data.nameProperty().bind(
                    Bindings.concat(
                        data.getName(), System.lineSeparator(), data.pieValueProperty(), " hours"
                    )
                )
            );
            
            // chart.setLegendVisible(false);
            
            chart.setLegendSide(Side.LEFT);
            chart.setLabelsVisible(false);
            
            chart.setTitle("Ambassador Hours by Major");
            hold_chart.getChildren().addAll(chart);
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
    }    
    
}
