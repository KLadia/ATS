package ats;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;


public class EventsScreenController implements Initializable {
    
    // edit side elements (left)
    
    @FXML
    private ComboBox admin;
    
    @FXML
    private ComboBox admin_component;
    
    @FXML
    private RadioButton admin_delete;
    
    @FXML
    private RadioButton admin_modify;
    
    @FXML
    private RadioButton admin_add;
    
    @FXML
    private TextField admin_value;
    
    @FXML
    private Label admin_status;
    
    @FXML
    private ComboBox event;
    
    @FXML
    private ComboBox event_component;
    
    @FXML
    private RadioButton event_delete;
    
    @FXML
    private RadioButton event_modify;
    
    @FXML
    private RadioButton event_add;
    
    @FXML
    private TextField event_value;
    
    @FXML
    private Label event_status;
    
    @FXML
    private ComboBox ambassador;
    
    @FXML
    private ComboBox ambassador_component;
    
    @FXML
    private RadioButton ambassador_delete;
    
    @FXML
    private RadioButton ambassador_modify;
    
    @FXML
    private RadioButton ambassador_add;
    
    @FXML
    private TextField ambassador_value;
    
    @FXML
    private Label ambassador_status;
    
    // log side elements (right)
    
    @FXML
    private Label ambassador_log;
    
    @FXML
    private Label event_log;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // add event components to dropdown
        event_component.getItems().addAll("Title", "Date", "Start Time", "End Time",
            "Description", "Notes", "Dress Code", "City", "State", "Zip", "Attendees");
        
        try {
            
            // add events to dropdown
            
            DBManager h2 = new DBManager();
            
            ArrayList<String> eventData = h2.getEventData();
            
            for(int i = 0; i < eventData.size(); i++) {
                                
                String id = eventData.get(i);
                
                if(!(i + 13 > eventData.size())) {
                    
                    event.getItems().addAll(eventData.get(i + 1));
                    
                }
                
                i += 12; // update to next event in list
            }

            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
        // add admin components to dropdown
        admin_component.getItems().addAll("Username", "Password");
        
        try {
            
            // add admins to dropdown
            
            DBManager h2 = new DBManager();
            
            ArrayList<String> adminData = h2.getAdminData();
            
            for(int i = 0; i < adminData.size(); i++) {
                                                
                if(!(i + 2 > adminData.size())) {
                    
                    admin.getItems().addAll(adminData.get(i));
                }
                
                i += 1; // update to admin event in list
            }

            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
        
        // add ambassador components to drop down list
        ambassador_component.getItems().addAll("UIN", "First Name", "Last Name",
            "Email", "Major", "Entry Semester", "Grad Year", "Bio");
        
        try {
            // add ambassadors to ambassador dropdown list
            DBManager h2 = new DBManager();
            
            ArrayList<String> ambassadorData = h2.getAmbassadorData();
            
            for(int i = 0; i < ambassadorData.size(); i++) {
                                                
                if(!(i + 9 > ambassadorData.size())) {
                    
                    ambassador.getItems().addAll(ambassadorData.get(i + 1) + " " + ambassadorData.get(i + 2));
                }
                
                i += 8; // update to next ambassador in list
            }
            
            h2.shutdown();
                
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
        try {
            // add logs to label
            DBManager h2 = new DBManager();
            
            ArrayList<String> logData = h2.getLogData();
            String store_logs = new String(); // used to set text of label
            
            for(int i = logData.size() - 1; i >= 0; i--) {
                
                if(!(i - 2 < 0)) {
                    store_logs += (logData.get(i) + System.lineSeparator());
                }
                
                i--;                    
            }
            
            ambassador_log.setText(store_logs);

            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
        try {
            // add logs to label
            DBManager h2 = new DBManager();
            
            ArrayList<String> logData = h2.getEventsLogData();
            String store_logs = new String(); // used to set text of label
            
            for(int i = logData.size() - 1; i >= 0; i--) {
                
                if(!(i - 2 < 0)) {
                    store_logs += (logData.get(i) + System.lineSeparator());
                }
                
                i--;                    
            }
            
            event_log.setText(store_logs);

            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
    }    
    
    @FXML
    private void editAmbassador(ActionEvent event) throws IOException {
        
    }
    
    @FXML
    private void editEvent(ActionEvent event) throws IOException {
        
    }
    
    @FXML
    private void editAdmin(ActionEvent event) throws IOException {
        
        boolean proceed = true;
        
        if(admin.getSelectionModel().isEmpty()) {
            admin_status.setText("Please select a user");
            proceed = false;
        }
        else if(admin_component.getSelectionModel().isEmpty()) {
            admin_status.setText("Please select a component");
            proceed = false;
        }
        
        
        if(proceed) {
            
            String user = admin.getValue().toString();
            String component = admin_component.getValue().toString();
        
        
            if(admin_delete.isSelected()) {
            
            }
            else if(admin_add.isSelected()) {
            
            }
            else if(admin_modify.isSelected()) {
            
            }
        }
    }
    
    @FXML
    private void home(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("CoordinatorHomepage.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void createEvent(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("CreateEvent.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void viewEvents(ActionEvent event) throws IOException {        
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("EventsScreen.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    
    @FXML
    private void adminFunctions(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("AdminFunctions.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void signOut(ActionEvent event) throws IOException {        
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
        
        // popup with successful logout message
        final Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("LogoutPopUp.fxml"));
        Scene popUpScene = new Scene(FXMLFramePopUp);
        popUpScene.getStylesheets().add(css);
        popup.setScene(popUpScene);
        popup.show();
    }
}
