package ats;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ModifyEvent implements Initializable {

    @FXML
    private Label header;
    
    @FXML
    private Label info;
    
    @FXML
    private TextField username;
    
    @FXML
    private TextField password;
    
    @FXML
    private Label status;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        status.setText("");
    }
    
    @FXML
    private void confirm(ActionEvent event) throws IOException {
        
        boolean proceed = true;
        
        if(!(username.getText().equals(Homepage.current_user)) || 
            !(password.getText().equals(Homepage.current_password))) {
            
            proceed = false;
            status.setText("Incorrect username or password");
        }
        
        if(proceed) {
            
            int id = 0;
            
            // get event id
            try {
                    DBManager h2 = new DBManager();
                    id = h2.getEventId(SystemFunctions.event_who);
                    h2.shutdown();
                    
            } catch (SQLException ex) { // catches for opening database connection
            } catch (ClassNotFoundException ex) {
            }
            
            String the_event = SystemFunctions.event_who;
            
            String component = SystemFunctions.event_what;
            String new_value = SystemFunctions.event_new;
            
            if(SystemFunctions.isEventDelete) { // archiving ambassador
                if(component != null && component.equals("All Events")) {
                    //archive all events
                }
                else {
                    try {
                        DBManager h2 = new DBManager();
                    
                        h2.deleteEvent(id);
                        status.setText("Event archived, close window to view changes");
                    
                        h2.shutdown();
                    
                    } catch (SQLException ex) { // catches for opening database connection
                    } catch (ClassNotFoundException ex) {
                    }
                }
            }
            else if(SystemFunctions.isEventModify) { // modifying ambassador
                
                // event components
                // event_component.getItems().addAll("Title", "Date", "Start Time", "End Time",
                // "Description", "Notes", "Dress Code", "City", "State", "Zip", "Attendees");
                
                if(component.equals("Title")) {
                    component = "title";
 
                    try {
                        DBManager h2 = new DBManager();
                        
                        h2.updateEventComponent(id, component, new_value); 
                        status.setText("Component changed, close window to view changes");
                    
                        h2.shutdown();
                            
                    } catch (SQLException ex) { // catches for opening database connection
                    } catch (ClassNotFoundException ex) {
                    }
                }
                else if(component.equals("Date")) {
                    component = "date";
                    try {
                        DBManager h2 = new DBManager();
                        
                        h2.updateEventComponent(id, component, new_value); 
                        status.setText("Component changed, close window to view changes");
                    
                        h2.shutdown();
                            
                    } catch (SQLException ex) { // catches for opening database connection
                    } catch (ClassNotFoundException ex) {
                    }
                }
                else if(component.equals("Start Time")) {
                    component = "start";
                    try {
                        DBManager h2 = new DBManager();
                        
                        h2.updateEventComponent(id, component, new_value); 
                        status.setText("Component changed, close window to view changes");
                    
                        h2.shutdown();
                            
                    } catch (SQLException ex) { // catches for opening database connection
                    } catch (ClassNotFoundException ex) {
                    }
                }
                else if(component.equals("End Time")) {
                    component = "until";
                    try {
                        DBManager h2 = new DBManager();
                        
                        h2.updateEventComponent(id, component, new_value); 
                        status.setText("Component changed, close window to view changes");
                    
                        h2.shutdown();
                            
                    } catch (SQLException ex) { // catches for opening database connection
                    } catch (ClassNotFoundException ex) {
                    }
                }
                else if(component.equals("Description")) {
                    component = "description";
                    try {
                        DBManager h2 = new DBManager();
                        
                        h2.updateEventComponent(id, component, new_value); 
                        status.setText("Component changed, close window to view changes");
                    
                        h2.shutdown();
                            
                    } catch (SQLException ex) { // catches for opening database connection
                    } catch (ClassNotFoundException ex) {
                    }
                }
                else if(component.equals("Notes")) {
                    component = "notes";
                    try {
                        DBManager h2 = new DBManager();
                        
                        h2.updateEventComponent(id, component, new_value); 
                        status.setText("Component changed, close window to view changes");
                    
                        h2.shutdown();
                            
                    } catch (SQLException ex) { // catches for opening database connection
                    } catch (ClassNotFoundException ex) {
                    }
                }
                else if(component.equals("Dress Code")) {
                    component = "dress_code";
                    try {
                        DBManager h2 = new DBManager();
                        
                        h2.updateEventComponent(id, component, new_value); 
                        status.setText("Component changed, close window to view changes");
                    
                        h2.shutdown();
                            
                    } catch (SQLException ex) { // catches for opening database connection
                    } catch (ClassNotFoundException ex) {
                    }
                }
                else if(component.equals("City")) {
                    component = "city";
                    try {
                        DBManager h2 = new DBManager();
                        
                        h2.updateEventComponent(id, component, new_value); 
                        status.setText("Component changed, close window to view changes");
                    
                        h2.shutdown();
                            
                    } catch (SQLException ex) { // catches for opening database connection
                    } catch (ClassNotFoundException ex) {
                    }
                }
                else if(component.equals("State")) {
                    component = "state";
                    try {
                        DBManager h2 = new DBManager();
                        
                        h2.updateEventComponent(id, component, new_value); 
                        status.setText("Component changed, close window to view changes");
                    
                        h2.shutdown();
                            
                    } catch (SQLException ex) { // catches for opening database connection
                    } catch (ClassNotFoundException ex) {
                    }
                }
                else if(component.equals("Zip")) {
                    component = "zip";
                    try {
                        DBManager h2 = new DBManager();
                        
                        h2.updateEventComponent(id, component, new_value); 
                        status.setText("Component changed, close window to view changes");
                    
                        h2.shutdown();
                            
                    } catch (SQLException ex) { // catches for opening database connection
                    } catch (ClassNotFoundException ex) {
                    }
                }
            }
        }  
    }
}
