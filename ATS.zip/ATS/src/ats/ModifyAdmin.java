package ats;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ModifyAdmin implements Initializable {
        
    @FXML
    private Label header;
    
    @FXML
    private Label info;
    
    @FXML
    private TextField username;
    
    @FXML
    private TextField password;
    
    @FXML
    private Label status;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        status.setText("");
    }
    
    @FXML
    private void confirm(ActionEvent event) throws IOException, 
        SQLException, ClassNotFoundException {
        
        DBManager h22 = new DBManager();
        
        boolean proceed = true;
        
        if(!(username.getText().equals(Homepage.current_user)) || 
            !(password.getText().equals(Homepage.current_password))) {
            
            proceed = false;
            status.setText("Only the outreach coordinator can edit administrators");
        }
        
        h22.shutdown();
        
        if(proceed) {
            
            String admin = SystemFunctions.admin_who;
            String component = SystemFunctions.admin_what;
            String new_value = SystemFunctions.admin_new;
            
            if(SystemFunctions.isAdminDelete) { // deleting from admin
                try {
                    DBManager h2 = new DBManager();
                    
                    h2.deleteAdmin(admin);
                    status.setText(admin + " deleted, close window to view changes");
                    
                    h2.shutdown();
                    
                } catch (SQLException ex) { // catches for opening database connection
                } catch (ClassNotFoundException ex) {
                }
            }
            else if(SystemFunctions.isAdminModify) { // modifying admin
                
                try {
                    DBManager h2 = new DBManager();
                    
                    h2.updateAdminPassword(admin, new_value);
                    status.setText("Password for " + admin + " changed, close window to view changes");
                    
                    h2.shutdown();
                    
                } catch (SQLException ex) { // catches for opening database connection
                } catch (ClassNotFoundException ex) {
                }

            }
        }
    }
    
}
