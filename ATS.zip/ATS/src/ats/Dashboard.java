package ats;

import java.awt.Font;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Side;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class Dashboard implements Initializable {
    
    // note that the vboxes have switched places
    
    @FXML
    private VBox pie_chart;
    
    @FXML
    private VBox line_chart;
    
    @FXML
    private Label upcoming;
    
    @FXML
    private Label today;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // for line chart
        
        //defining the axes
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        
        xAxis.setLabel("Event");
        
        //creating the chart
        final LineChart<String,Number> lineChart = new LineChart<String,Number>(xAxis,yAxis);
                
        lineChart.setTitle("Event Attendance");
        
        //defining a series
        XYChart.Series series = new XYChart.Series();
        XYChart.Series series2 = new XYChart.Series();
        
        series.setName("Off Campus");
        series2.setName("On Campus");
        
        String address = new String(); // for tracking on or off campus event
        String title = new String();
        
        try {
            
            DBManager h2 = new DBManager();
            
            ArrayList<String> eventData = h2.getEventData();
            
            for(int i = 0; i < eventData.size(); i++) {
                                
                String id = eventData.get(i);
                
                if(!(i + 13 > eventData.size())) {
                    
                    title = eventData.get(i + 1);
                    address = eventData.get(i + 8);
                    
                    if(address.contains("FGCU")) { // it's an on campus event
                        series.getData().add(new XYChart.Data(title, 
                            h2.countEventAttendees(id)));
                    }
                    else {
                        series2.getData().add(new XYChart.Data(title, 
                            h2.countEventAttendees(id)));
                    }
                    
                }
                
                i += 12; // update to next ambassador in list
            }

            h2.shutdown();
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
        lineChart.getData().addAll(series, series2);
        pie_chart.getChildren().addAll(lineChart);
        
        
        // now for the pie chart
        
        ObservableList<PieChart.Data> pieChartData;
        
        try {
            
            DBManager h2 = new DBManager();
            
            pieChartData =
                FXCollections.observableArrayList(
                new PieChart.Data("Software", h2.getHoursByMajor("Software Engineering")),
                new PieChart.Data("Environmental", h2.getHoursByMajor("Environmental Engineering")),
                new PieChart.Data("Bio", h2.getHoursByMajor("Bioengineering")),
                new PieChart.Data("Civil", h2.getHoursByMajor("Civil Engineering"))
            );
            
            h2.shutdown();
            
            final PieChart chart = new PieChart(pieChartData);
            
            pieChartData.forEach(
                data -> data.nameProperty().bind(
                    Bindings.concat(
                        data.getName(), System.lineSeparator(), data.pieValueProperty(), " hours"
                    )
                )
            );
            
            // chart.setLegendVisible(false);
            
            chart.setLegendSide(Side.LEFT);
            chart.setLabelsVisible(false);
            
            chart.setTitle("Ambassador Hours by Major");
            line_chart.getChildren().addAll(chart);
            
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
        // populate today's events
        try {
            
            // get today's date
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String date = sdf.format(new Date()); 
                    
            DBManager h2 = new DBManager();
            
            ArrayList<String> todaysEvents = h2.getTodaysEvents(date);
            
            ArrayList<String> attendees = new ArrayList<String>();
            String id = new String();
            String attenders = new String();
            
            String todaysEventsText = new String();
            
            if(todaysEvents.isEmpty()) {
                today.setText("No Events Today :(" + System.lineSeparator() +
                    "Sad Eagles");
            }
            else {
                for(int i = 0; i < todaysEvents.size(); i++) {
                
                    id = todaysEvents.get(i); // get ID based on title
                 
                    if(!(i + 11 > todaysEvents.size())) {
                   
                        // create string for label text
                        todaysEventsText += todaysEvents.get(i + 1) + " @ " + todaysEvents.get(i + 2) +
                            " to " + todaysEvents.get(i + 3) + ": " + todaysEvents.get(i + 4) +
                            System.lineSeparator() + "Notes: " + todaysEvents.get(i + 5) +
                            System.lineSeparator() + "Dress Code: " + todaysEvents.get(i + 6) +
                            System.lineSeparator() + "Where: " + todaysEvents.get(i + 7) + 
                                ", " + todaysEvents.get(i + 8) + ", " + todaysEvents.get(i + 9) +
                                " " + todaysEvents.get(i + 10) + 
                            System.lineSeparator() + "Attendees: " + h2.getEventAttendees(id) +
                            System.lineSeparator() + System.lineSeparator();
                    }
                
                    i += 10; 
                }   
              
                h2.shutdown();
            
                today.setText(todaysEventsText);
            }
                
        } catch (SQLException ex) { // catches for opening database connection
        } catch (ClassNotFoundException ex) {
        }
        
    } 
    
    @FXML
    private void inactiveAmbassadors(ActionEvent event) throws IOException {
        final Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("ArchivedAmbassadors.fxml"));
        Scene popUpScene = new Scene(FXMLFramePopUp);
        String css = ATS.class.getResource("CSS_PopUps.css").toExternalForm();
        popUpScene.getStylesheets().add(css);
        popup.setScene(popUpScene);
        popup.show();
    }
    
    @FXML
    private void archivedEvents(ActionEvent event) throws IOException {
        final Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("ArchivedEvents.fxml"));
        Scene popUpScene = new Scene(FXMLFramePopUp);
        String css = ATS.class.getResource("CSS_PopUps.css").toExternalForm();
        popUpScene.getStylesheets().add(css);
        popup.setScene(popUpScene);
        popup.show();
    }
    
    @FXML
    private void eventAttendence(ActionEvent event) throws IOException {
        final Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("ArchivedAttendence.fxml"));
        Scene popUpScene = new Scene(FXMLFramePopUp);
        String css = ATS.class.getResource("CSS_PopUps.css").toExternalForm();
        popUpScene.getStylesheets().add(css);
        popup.setScene(popUpScene);
        popup.show();
    }
    
    @FXML
    private void ambassadorHours(ActionEvent event) throws IOException {
        final Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("ArchivedHours.fxml"));
        Scene popUpScene = new Scene(FXMLFramePopUp);
        String css = ATS.class.getResource("CSS_PopUps.css").toExternalForm();
        popUpScene.getStylesheets().add(css);
        popup.setScene(popUpScene);
        popup.show();
    }
    
    @FXML
    private void home(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void createEvent(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("EventManager.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void viewEvents(ActionEvent event) throws IOException {        
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("SystemFunctions.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    
    @FXML
    private void adminFunctions(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("AmbassadorManager.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void signOut(ActionEvent event) throws IOException {        
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = ATS.class.getResource("CSS.css").toExternalForm();
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
        
        // popup with successful logout message
        final Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("Logout.fxml"));
        Scene popUpScene = new Scene(FXMLFramePopUp);
        popUpScene.getStylesheets().add(css);
        popup.setScene(popUpScene);
        popup.show();
    }
}
