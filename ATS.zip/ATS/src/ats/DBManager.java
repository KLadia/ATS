package ats;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author chelseaatkins
 */
public class DBManager {
    private Connection connection;

    public DBManager() throws SQLException, ClassNotFoundException {
        
        Class.forName("org.h2.Driver");
        connection = DriverManager.getConnection("jdbc:h2:" + System.getProperty("user.dir")+ "/db/ats", "ats", "admin");
	Statement statement = connection.createStatement();
        
        // table for administrators
        statement.execute("create table if not exists admin (" + 
            "username varchar(100)," +
            "password varchar(100)," +
            "constraint pk_username_id primary key (username));"
        );
        
        // table for ambassador hours data tracking
        statement.execute("create table if not exists archived_hours (" +
            "archive_id smallint," +
            "major varchar(100)," +
            "date varchar(100)," +
            "hours smallint," +
            "constraint pk_ambassador_archive_id primary key (archive_id));"
        );
        
        // table for ambassadors
        statement.execute("create table if not exists ambassador (" + 
            "uin varchar(100)," +
            "firstname varchar(100)," +
            "lastname varchar(100)," +
            "email varchar(100)," +
            "major varchar(100)," + 
            "catalog varchar(100)," +
            "grad varchar(100)," +
            "bio varchar(300)," +
            "hours smallint," +
            "constraint pk_ambassador_uin primary key (uin));"
        );
        
        // table for archived ambassadors
        statement.execute("create table if not exists archived_ambassadors (" + 
            "uin varchar(100)," +
            "firstname varchar(100)," +
            "lastname varchar(100)," +
            "email varchar(100)," +
            "major varchar(100)," + 
            "catalog varchar(100)," +
            "grad varchar(100)," +
            "bio varchar(300)," +
            "hours smallint," +
            "constraint pk_ambassador_email primary key (email));"
        );
        
        // table for events
        statement.execute("create table if not exists event (" +
            "id smallint," +
            "title varchar(100)," +
            "date varchar(100)," +
            "start varchar(100)," +
            "until varchar(100)," +
            "description varchar(500)," +
            "notes varchar(300)," +
            "dress_code varchar(100)," +
            "address varchar(100)," +
            "city varchar(100)," +
            "state varchar(100)," +
            "zip varchar(100)," +
            "atendees varchar(500)," +
            "constraint pk_event_id primary key (id));"
        );
        
        // table for archived events
        statement.execute("create table if not exists archived_events (" +
            "id smallint," +
            "title varchar(100)," +
            "date varchar(100)," +
            "start varchar(100)," +
            "until varchar(100)," +
            "description varchar(500)," +
            "notes varchar(300)," +
            "dress_code varchar(100)," +
            "address varchar(100)," +
            "city varchar(100)," +
            "state varchar(100)," +
            "zip varchar(100)," +
            "atendees varchar(500)," +
            "constraint pk_event_title primary key (title));"
        );
        
        // table for event attendees
        statement.execute("create table if not exists attendance (" +
            "holder smallint," +
            "id smallint," +
            "attendees varchar(500)," +
            "constraint pk_holder primary key (holder));"
        );
        
        // table for logging hours updates
        statement.execute("create table if not exists actions_hours (" + 
            "logged smallint," +
            "action varchar(200)," +
            "constraint pk_logged primary key (logged));"
        );
        
        // table for logging attendees updates
        statement.execute("create table if not exists actions_attendees (" + 
            "index smallint," +
            "added varchar(200)," +
            "constraint pk_added primary key (added));"
        );
        
    }
    
    // method for closing database connection
    public void shutdown() throws SQLException {
        if (connection != null) {
            connection.close();
        }
    }
    
    // get events that happen on the current day
    public ArrayList<String> getTodaysEvents(String date) throws SQLException {
        
        // select title from event where date = '2018-04-01'
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select id, title, start, until, "
            + "description, notes, dress_code, address, city, state, zip"
            + " from event where date = '" + date + "';");
       
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String id = rs.getString("id");
            String title = rs.getString("title");
            String start = rs.getString("start");
            String until = rs.getString("until");
            String description = rs.getString("description");
            String notes = rs.getString("notes");
            String dress_code = rs.getString("dress_code");
            String address = rs.getString("address");
            String city = rs.getString("city");
            String state = rs.getString("state");
            String zip = rs.getString("zip");
            
            list.add(id);
            list.add(title);
            list.add(start);
            list.add(until);
            list.add(description);
            list.add(notes);
            list.add(dress_code);
            list.add(address);
            list.add(city);
            list.add(state);
            list.add(zip);

        }
        
        return list;
    }
    
    // create a new ambassador
    public void insertEvent(int id, String title, String date, String start, String until, 
            String description, String notes, String dress_code, String address, String city,
            String state, String zip, String attendees) throws SQLException, ClassNotFoundException {
                
        Statement statement = connection.createStatement();
        
        statement.execute("MERGE INTO EVENT VALUES('" + id + "','" + title + "','" + date + 
                "','" + start + "','" + until + "','" + description + "','" + notes + "','" + dress_code + "','" 
                + address + "','" + city + "','" + state + "','" + zip + "','" + attendees + "');"
        );
    }
    
    // update log of hours
    public void updateLog(int logged, String action)
            throws SQLException, ClassNotFoundException {
                
        Statement statement = connection.createStatement();
        
        statement.execute("MERGE INTO ACTIONS_HOURS VALUES('" + logged + "','" + action + "');");
        
    }
    
    // update log of hours
    public void updateLogEvents(int index, String added)
            throws SQLException, ClassNotFoundException {
                
        Statement statement = connection.createStatement();
        
        statement.execute("MERGE INTO ACTIONS_ATTENDEES VALUES('" + index + "','" + added + "');");
        
    }
    
    // count current log number to update holder
    public int getLogCountEvents() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select count(*) from ACTIONS_ATTENDEES");
        
        String num_logged = new String();
        
        while(rs.next()) {
            num_logged = rs.getString("count(*)");
        }
        
        int num = Integer.parseInt(num_logged);
        
        return num;
        
    }
    
    // count current log number to update holder
    public int getLogCount() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select count(*) from actions_hours");
        
        String num_logged = new String();
        
        while(rs.next()) {
            num_logged = rs.getString("count(*)");
        }
        
        int num = Integer.parseInt(num_logged);
        
        return num;
        
    }
    
    // get list of people attending an event based on event id
    public ArrayList<String> getEventAttendees(String id) throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select * from attendance where id = '" + id + "';");
       
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String attendees = rs.getString("attendees");
            list.add(attendees);
        }
        
        return list;
        
    }
    
    // find number of attendees for an event
    public int countEventAttendees(String id) throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select count(*) from attendance"
                + " where id = '" + id + "';");
       
        String num = new String();
        
        while(rs.next()) {
            num = rs.getString("count(*)");
        }
        
        return Integer.parseInt(num);
        
    }
    
    // get event id based on event name
    public int getEventId(String title) throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select id from event where title = '" + title + "';");
        
        String id = new String();
        
        while(rs.next()) {
            id = rs.getString("id");
        }
        
        return Integer.parseInt(id);
    }
    
    // get total number of ambassadors in system (for login screen, basically)
    public int getTotalAmbassadors() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select count(*) from ambassador");
        
        String num_events = new String();
        
        while(rs.next()) {
            num_events = rs.getString("count(*)");
        }
        
        int num = Integer.parseInt(num_events);
        
        return num;
    }
    
    // get total number of service hours in system (for login screen, basically)
    public int getTotalHours() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select sum(hours) from ambassador");

        String num = new String();
        
        while(rs.next()) {
            num = rs.getString("sum(hours)");
        }
        
        int total = Integer.parseInt(num);
        
        return total;
    }
    
    // also for login screen
    public int getTotalHoursArchived() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select sum(hours) from archived_ambassadors");

        String num = new String();
        
        while(rs.next()) {
            num = rs.getString("sum(hours)");
        }
        
        int total = Integer.parseInt(num);
        
        return total;
    }
    
    // get the count for the current number of events in database
    // this is important - event id will increase by one with each new addition
    public int getEventCount() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select count(*) from event");
        
        String num_events = new String();
        
        while(rs.next()) {
            num_events = rs.getString("count(*)");
        }
        
        int num = Integer.parseInt(num_events);
        
        return num;
        
    }
    
    // get the count for the current holder row position of attendance
    // holder id will increase by one with each new addition when inserted
    public int getHolderCount() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select count(*) from attendance");
        
        String num_holders = new String();
        
        while(rs.next()) {
            num_holders = rs.getString("count(*)");
        }
        
        int num = Integer.parseInt(num_holders);
        
        return num;
        
    }
    
    // create a new ambassador
    public void insertAmbassador(String uin, String firstname, String lastname, String email, 
            String major, String catalog, String grad, String bio, int hours) 
            throws SQLException, ClassNotFoundException {
                
        Statement statement = connection.createStatement();
        
        statement.execute("MERGE INTO AMBASSADOR VALUES('" + uin + "','" + firstname + "','" + lastname + 
                "','" + email + "','" + major + "','" + catalog + "','" + grad + "','" 
                + bio + "','" + hours + "');"
        );
    }

    // get event id based on title
    public int getEventID(String title) 
        throws SQLException, ClassNotFoundException {
        
        // hardcoded example query
        // select id from event
        // where title = 'Sample' // case sensitive
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select id from event"
                + " where title = '" + title + "';");
        
        String num = new String();
        
        while(rs.next()) {
            num = rs.getString("id");
        }
        
        return Integer.parseInt(num);
    }
    
    // add event attendee to attendance table based on event id
    public void addEventAttendee(int id, String name) 
        throws SQLException, ClassNotFoundException {
                
        Statement statement = connection.createStatement();
        
        ResultSet rs = statement.executeQuery("select count(*) from attendance");
        
        String num = new String();
        
        while(rs.next()) {
            num = rs.getString("count(*)");
        }
        
        int holder_update = Integer.parseInt(num);
        holder_update += 1; // update holder primary key
        
        /* reference table
        statement.execute("create table if not exists attendance (" +
            "holder smallint," +
            "id smallint," +
            "attendees varchar(500)," +
            "constraint pk_holder primary key (holder));"
        );
        */

        statement.execute("MERGE INTO attendance VALUES('" + holder_update + "','" 
            + id + "','" + name + "');"
        );
    }
    
    // get ambassador data into array list
    public ArrayList<String> getAmbassadorData() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select * from ambassador order by lastname");
       
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String uin = rs.getString("uin");
            String firstname = rs.getString("firstname");
            String lastname = rs.getString("lastname");
            String email = rs.getString("email");
            String major = rs.getString("major");
            String catalog = rs.getString("catalog");
            String grad = rs.getString("grad");
            String bio = rs.getString("bio");
            String hours = rs.getString("hours");
            
            list.add(uin);
            list.add(firstname);
            list.add(lastname);
            list.add(email);
            list.add(major);
            list.add(catalog);
            list.add(grad);
            list.add(bio);
            list.add(hours);
        }
        
        return list;
    }
    
    // get archived ambassador data into array list
    public ArrayList<String> getAmbassadorDataArchived() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select * from archived_ambassadors order by lastname");
       
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String uin = rs.getString("uin");
            String firstname = rs.getString("firstname");
            String lastname = rs.getString("lastname");
            String email = rs.getString("email");
            String major = rs.getString("major");
            String catalog = rs.getString("catalog");
            String grad = rs.getString("grad");
            String bio = rs.getString("bio");
            String hours = rs.getString("hours");
            
            list.add(uin);
            list.add(firstname);
            list.add(lastname);
            list.add(email);
            list.add(major);
            list.add(catalog);
            list.add(grad);
            list.add(bio);
            list.add(hours);
        }
        
        return list;
    }
    
    // get event data into array list
    public ArrayList<String> getEventData() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select * from event");
       
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String id = rs.getString("id");
            String title = rs.getString("title");
            String date = rs.getString("date");
            String start = rs.getString("start");
            String until = rs.getString("until");
            String description = rs.getString("description");
            String notes = rs.getString("notes");
            String dress_code = rs.getString("dress_code");
            String address = rs.getString("address");
            String city = rs.getString("city");
            String state = rs.getString("state");
            String zip = rs.getString("zip");
            String attendees = rs.getString("attendees");
            
            list.add(id);
            list.add(title);
            list.add(date);
            list.add(start);
            list.add(until);
            list.add(description);
            list.add(notes);
            list.add(dress_code);
            list.add(address);
            list.add(city);
            list.add(state);
            list.add(zip);
            list.add(attendees);
        }
        
        return list;
    }
    
    // get archived event data into array list
    public ArrayList<String> getEventDataArchived() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select * from archived_events order by date;");
       
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String id = rs.getString("id");
            String title = rs.getString("title");
            String date = rs.getString("date");
            String start = rs.getString("start");
            String until = rs.getString("until");
            String description = rs.getString("description");
            String notes = rs.getString("notes");
            String dress_code = rs.getString("dress_code");
            String address = rs.getString("address");
            String city = rs.getString("city");
            String state = rs.getString("state");
            String zip = rs.getString("zip");
            
            list.add(id);
            list.add(title);
            list.add(date);
            list.add(start);
            list.add(until);
            list.add(description);
            list.add(notes);
            list.add(dress_code);
            list.add(address);
            list.add(city);
            list.add(state);
            list.add(zip);
        }
        
        return list;
    }
    
    // change a specified ambassadors hours
    public void updateAmbassadorHours(String uin, int hours) throws SQLException {
        
        // sample update hours query (hardcoded)
        // UPDATE AMBASSADOR SET HOURS = 3
        // WHERE UIN = 777777999;
        
        Statement statement = connection.createStatement();
        statement.execute("update ambassador set hours = " + hours +
                "where uin = " + uin + ";");
        
    }
    
    // get total hours by ambassador major
    public int getHoursByMajor(String major) throws SQLException {
        
        // select sum(hours) from ambassador
        // where major = 'Software Engineering'
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select sum(hours) from ambassador" +
            " where major = '" + major + "';");
        
        String num = new String();
        
        while(rs.next()) {
            num = rs.getString("sum(hours)");
        }
        
        if(num == null) {
            return 0;
        }
        
        return Integer.parseInt(num);
        
    }
    
    // get ambassador hours based on uin
    public int getAmbassadorHours(String uin) throws SQLException {
        
        // sample get hours query (hardcoded)
        // SELECT HOURS FROM AMBASSADOR
        // WHERE UIN = 815065902;
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select hours from ambassador "
                + "where uin = '" + uin + "';");
        
        String hours = new String();
        
        while(rs.next()) {
            hours = rs.getString("hours");
        }
        
        int hrs = Integer.parseInt(hours);
        
        return hrs;
        
    }
    
    // find an ambassadors uin based on first and last name
    public String getAmbassadorUIN(String firstname, String lastname) throws SQLException {
        
        // find UIN based on first and last name sample query
        // SELECT UIN FROM AMBASSADOR
        // WHERE FIRSTNAME = 'Chelsea' AND LASTNAME = 'Atkins';
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select uin from ambassador "
                + "where firstname = '" + firstname + "' and lastname = '" + lastname + "'");
        
        String uin = new String();
        
        while(rs.next()) {
            uin = rs.getString("uin");
        }
        
        return uin;
    }
    
    // get all active ambassador uin
    public ArrayList<String> pullUINS() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select uin from ambassador");
        
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String uin = rs.getString("uin");
            
            list.add(uin);
        }
        
        return list;
    }
    
    // get full name of an ambassador into each element of a list
    public ArrayList<String> pullFullName() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select firstname, lastname from ambassador");
        
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String firstname = rs.getString("firstname");
            String lastname = rs.getString("lastname");
            
            list.add(firstname + " " + lastname);
        }
        
        return list;
    }
    
    // get titles of all events
    public ArrayList<String> pullEventTitles() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select title from event");
        
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String title = rs.getString("title");
            
            list.add(title);
        }
        
        return list;
    }
    
    // create a new administrator
    public void insertAdmin (String username, String password) throws SQLException, ClassNotFoundException {
        Statement statement = connection.createStatement();
        statement.execute("MERGE INTO ADMIN VALUES('" + username + "','" + password + "');");	
    }
    
    // get data in the log into a list
    public ArrayList<String> getLogData() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select * from actions_hours");
       
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String logged = rs.getString("logged");
            String action = rs.getString("action");
            list.add(logged);
            list.add(action);
        }
        
        return list;
        
    }
    
    // get data in the event attendees log into a list
    public ArrayList<String> getEventsLogData() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select * from actions_attendees");
       
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String index = rs.getString("index");
            String added = rs.getString("added");
            list.add(index);
            list.add(added);
        }
        
        return list;
        
    }
    
    // get administrator data into array list
    public ArrayList<String> getAdminData() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select * from admin");
       
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String username = rs.getString("username");
            String password = rs.getString("password");
            list.add(username);
            list.add(password);
        }
        
        return list;
    }
    
    
    // delete specific admin
    public void deleteAdmin(String username) throws SQLException {
       
        Statement statement = connection.createStatement();
        statement.execute("delete from admin where username = '" + username + "';");
        
    }
    
    // change password of an administrator
    public void updateAdminPassword(String username, String password) throws SQLException {
     
        Statement statement = connection.createStatement();
        statement.execute("update admin set password = '" + password +
            "' where username = '" + username + "';");
        
    }
    
    // delete specific ambassador
    public void deleteAmbassador(String uin) throws SQLException {
       
        Statement statement = connection.createStatement();
        
        // first add to archive table
        ResultSet rs = statement.executeQuery("select * from ambassador "
                + "where uin = '" + uin + "';");
        
        String firstname = new String();
        String lastname = new String();
        String email = new String();
        String major = new String();
        String catalog = new String();
        String grad = new String();
        String bio = new String();
        String hours = new String();
        
        while(rs.next()) {
            firstname = rs.getString("firstname");
            lastname = rs.getString("lastname");
            email = rs.getString("email");
            major = rs.getString("major");
            catalog = rs.getString("catalog");
            grad = rs.getString("grad");
            bio = rs.getString("bio");
            hours = rs.getString("hours");
        }
        
        statement.execute("MERGE INTO ARCHIVED_AMBASSADORS VALUES('" + uin + "','" + firstname + "','" + lastname + 
                "','" + email + "','" + major + "','" + catalog + "','" + grad + "','" 
                + bio + "','" + hours + "');"
        );
        
        // now delete from active table
        statement.execute("delete from ambassador where uin = '" + uin + "';");
        
    }
    
    // delete specific event (archive it...)
    public void deleteEvent(int id) throws SQLException {
       
        Statement statement = connection.createStatement();
        
        // first add to archive table
        ResultSet rs = statement.executeQuery("select * from event "
                + "where id = " + id + ";");
        
        String title = new String();
        String date = new String();
        String start = new String();
        String until = new String();
        String description = new String();
        String notes = new String();
        String dress_code = new String();
        String address = new String();
        String city = new String();
        String state = new String();
        String zip = new String();
        
        while(rs.next()) {
            title = rs.getString("title");
            date = rs.getString("date");
            start = rs.getString("start");
            until = rs.getString("until");
            description = rs.getString("description");
            notes = rs.getString("notes");
            dress_code = rs.getString("dress_code");
            address = rs.getString("address");
            city = rs.getString("city");
            state = rs.getString("state");
            zip = rs.getString("zip");
        }
        
        ResultSet rs2 = statement.executeQuery("select * from attendance where id = '" + id + "';");
       
        ArrayList<String> list = new ArrayList<>();
        String all_attendees = new String();
        
        while(rs2.next()) {
            String attendees = rs2.getString("attendees");
            list.add(attendees);
        }
        
        for(int i = 0; i < list.size(); i++) {
            all_attendees += list.get(i) + ",";
        }
        
        statement.execute("MERGE INTO ARCHIVED_EVENTS VALUES('" + id + "','" + title + "','" + date + 
                "','" + start + "','" + until + "','" + description + "','" + notes + "','" + dress_code + "','" 
                + address + "','" + city + "','" + state + "','" + zip + "','" + all_attendees + "');"
        );
        
        // now delete from active table
        statement.execute("delete from event where id = " + id + ";");
        
    }
    
    // update a specific component for an ambassador
    public void updateAmbassadorComponent(String uin, String component, String new_value) throws SQLException {
     
        Statement statement = connection.createStatement();
        statement.execute("update ambassador set " + component + " = '" + new_value +
            "' where uin = '" + uin + "';");
        
    }
    
    // update a specific component for an event
    public void updateEventComponent(int id, String component, String new_value) throws SQLException {
     
        Statement statement = connection.createStatement();
        statement.execute("update event set " + component + " = '" + new_value +
            "' where id = " + id + ";");
        
    }
    
    // clear ambassador log
    public void clearAmbassadorLog() throws SQLException {
     
        Statement statement = connection.createStatement();
        statement.execute("drop table if exists actions_hours;");
        
    }
    
    // clear events log
    public void clearEventsLog() throws SQLException {
     
        Statement statement = connection.createStatement();
        statement.execute("drop table if exists actions_attendees;");
        
    }
    
    public ArrayList<String> getEventsBetweenDate(String from_date, String to_date) throws SQLException {
        
        // SELECT * FROM EVENT
        // WHERE date BETWEEN '2018-04-01' AND '2018-04-18'
        // order by date
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select * from event where date between"
                + "'" + from_date + "' and " + "'" + to_date + "' order by date;");
       
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String id = rs.getString("id");
            String title = rs.getString("title");
            String date = rs.getString("date");
            String start = rs.getString("start");
            String until = rs.getString("until");
            String description = rs.getString("description");
            String notes = rs.getString("notes");
            String dress_code = rs.getString("dress_code");
            String address = rs.getString("address");
            String city = rs.getString("city");
            String state = rs.getString("state");
            String zip = rs.getString("zip");
            String attendees = rs.getString("attendees");
            
            list.add(id);
            list.add(title);
            list.add(date);
            list.add(start);
            list.add(until);
            list.add(description);
            list.add(notes);
            list.add(dress_code);
            list.add(address);
            list.add(city);
            list.add(state);
            list.add(zip);
            list.add(attendees);
        }
        
        return list;
        
    }
    
    // merge data into archive whenever hours are added to an ambassador 
    public void archiveHours(String uin, String event_title, int hours) throws SQLException {
        
        Statement statement = connection.createStatement();
        
        ResultSet rs = statement.executeQuery("select major from ambassador "
            + "where uin = '" + uin + "';");
        
        String major = new String();
        while(rs.next()) {
            major = rs.getString("major");
        }
        
        ResultSet rs2 = statement.executeQuery("select date from event "
            + "where title = '" + event_title + "';");
        
        String date = new String();
        while(rs2.next()) {
            date = rs2.getString("date");
        }
        
        ResultSet rs3 = statement.executeQuery("select count(*) from archived_hours;");
        
        String id = new String();
        while(rs3.next()) {
            id = rs3.getString("count(*)");
        }
        
        int archive_id = Integer.parseInt(id) + 1;
        
        statement.execute("MERGE INTO ARCHIVED_HOURS VALUES('" + archive_id + "','" + 
            major + "','" + date + "','" + hours + "');"
        );
        
    }
    
    // get total hours by ambassador major (from archived table)
    public int getArchivedHoursByMajor(String major, String from_date, String to_date) throws SQLException {
        
        // select sum(hours) from ambassador
        // where major = 'Software Engineering'
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select sum(hours) from archived_hours" +
            " where major = '" + major + "' and date between " + "'" + 
            from_date + "' and " + "'" + to_date + "';"
        );
        
        String num = new String();
        
        while(rs.next()) {
            num = rs.getString("sum(hours)");
        }
        
        if(num == null) {
            return 0;
        }
        
        return Integer.parseInt(num);
        
    }
    
    // get password of administrator based on username
    public String getPassword(String username) throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select password from admin where"
            + " username = '" + username + "';");
        
        String password = new String();
        
        while(rs.next()) {
            password = rs.getString("password");
        }
        
        return password;
    }
}
