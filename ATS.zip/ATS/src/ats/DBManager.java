/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ats;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author chelseaatkins
 */
public class DBManager {
    private Connection connection;

    public DBManager() throws SQLException, ClassNotFoundException {
        
        Class.forName("org.h2.Driver");
        connection = DriverManager.getConnection("jdbc:h2:" + System.getProperty("user.dir")+ "/db/ats", "ats", "admin");
	Statement statement = connection.createStatement();
        
        // table for administrators
        statement.execute("create table if not exists admin (" + 
            "username varchar(100)," +
            "password varchar(100)," +
            "constraint pk_username_id primary key (username));"
        );
        
        // table for ambassadors
        statement.execute("create table if not exists ambassador (" + 
            "uin varchar(100)," +
            "firstname varchar(100)," +
            "lastname varchar(100)," +
            "email varchar(100)," +
            "major varchar(100)," + 
            "catalog varchar(100)," +
            "grad varchar(100)," +
            "bio varchar(300)," +
            "hours smallint," +
            "constraint pk_ambassador_uin primary key (uin));"
        );
        
        // table for events
        statement.execute("create table if not exists event (" +
            "id smallint," +
            "title varchar(100)," +
            "date varchar(100)," +
            "start varchar(100)," +
            "until varchar(100)," +
            "description varchar(500)," +
            "notes varchar(300)," +
            "dress_code varchar(100)," +
            "address varchar(100)," +
            "city varchar(100)," +
            "state varchar(100)," +
            "zip varchar(100)," +
            "atendees varchar(500)," +
            "constraint pk_event_id primary key (id));"
        );
        
        // table for event attendees
        statement.execute("create table if not exists attendance (" +
            "holder smallint," +
            "id smallint," +
            "attendees varchar(500)," +
            "constraint pk_holder primary key (holder));"
        );
        
        // table for logging hours updates
        statement.execute("create table if not exists actions_hours (" + 
            "logged smallint," +
            "action varchar(200)," +
            "constraint pk_logged primary key (logged));"
        );
        
        // table for logging attendees updates
        statement.execute("create table if not exists actions_attendees (" + 
            "index smallint," +
            "added varchar(200)," +
            "constraint pk_added primary key (added));"
        );
        
    }
    
    // method for closing database connection
    public void shutdown() throws SQLException {
        if (connection != null) {
            connection.close();
        }
    }
    
    // get events that happen on the current day
    public ArrayList<String> getTodaysEvents(String date) throws SQLException {
        
        // select title from event where date = '2018-04-01'
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select id, title, start, until, "
            + "description, notes, dress_code, address, city, state, zip"
            + " from event where date = '" + date + "';");
       
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String id = rs.getString("id");
            String title = rs.getString("title");
            String start = rs.getString("start");
            String until = rs.getString("until");
            String description = rs.getString("description");
            String notes = rs.getString("notes");
            String dress_code = rs.getString("dress_code");
            String address = rs.getString("address");
            String city = rs.getString("city");
            String state = rs.getString("state");
            String zip = rs.getString("zip");
            
            list.add(id);
            list.add(title);
            list.add(start);
            list.add(description);
            list.add(notes);
            list.add(dress_code);
            list.add(address);
            list.add(city);
            list.add(state);
            list.add(zip);
            list.add(until);

        }
        
        return list;
    }
    
    // create a new ambassador
    public void insertEvent(int id, String title, String date, String start, String until, 
            String description, String notes, String dress_code, String address, String city,
            String state, String zip, String attendees) throws SQLException, ClassNotFoundException {
                
        Statement statement = connection.createStatement();
        
        statement.execute("MERGE INTO EVENT VALUES('" + id + "','" + title + "','" + date + 
                "','" + start + "','" + until + "','" + description + "','" + notes + "','" + dress_code + "','" 
                + address + "','" + city + "','" + state + "','" + zip + "','" + attendees + "');"
        );
    }
    
    // update log of hours
    public void updateLog(int logged, String action)
            throws SQLException, ClassNotFoundException {
                
        Statement statement = connection.createStatement();
        
        statement.execute("MERGE INTO ACTIONS_HOURS VALUES('" + logged + "','" + action + "');");
        
    }
    
    // update log of hours
    public void updateLogEvents(int index, String added)
            throws SQLException, ClassNotFoundException {
                
        Statement statement = connection.createStatement();
        
        statement.execute("MERGE INTO ACTIONS_ATTENDEES VALUES('" + index + "','" + added + "');");
        
    }
    
    // count current log number to update holder
    public int getLogCountEvents() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select count(*) from ACTIONS_ATTENDEES");
        
        String num_logged = new String();
        
        while(rs.next()) {
            num_logged = rs.getString("count(*)");
        }
        
        int num = Integer.parseInt(num_logged);
        
        return num;
        
    }
    
    // count current log number to update holder
    public int getLogCount() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select count(*) from actions_hours");
        
        String num_logged = new String();
        
        while(rs.next()) {
            num_logged = rs.getString("count(*)");
        }
        
        int num = Integer.parseInt(num_logged);
        
        return num;
        
    }
    
    // get list of people attending an event based on event id
    public ArrayList<String> getEventAttendees(String id) throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select * from attendance where id = '" + id + "';");
       
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String attendees = rs.getString("attendees");
            list.add(attendees);
        }
        
        return list;
        
    }
    
    // find number of attendees for an event
    public int countEventAttendees(String id) throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select count(*) from attendance"
                + " where id = '" + id + "';");
       
        String num = new String();
        
        while(rs.next()) {
            num = rs.getString("count(*)");
        }
        
        return Integer.parseInt(num);
        
    }
    
    // get event id based on event name
    public int getEventId(String title) throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select id from event where title = '" + title + "';");
        
        String id = new String();
        
        while(rs.next()) {
            id = rs.getString("id");
        }
        
        return Integer.parseInt(id);
    }
    
    // get total number of ambassadors in system (for login screen, basically)
    public int getTotalAmbassadors() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select count(*) from ambassador");
        
        String num_events = new String();
        
        while(rs.next()) {
            num_events = rs.getString("count(*)");
        }
        
        int num = Integer.parseInt(num_events);
        
        return num;
    }
    
    // get total number of service hours in system (for login screen, basically)
    public int getTotalHours() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select sum(hours) from ambassador");
        
        String num = new String();
        
        while(rs.next()) {
            num = rs.getString("sum(hours)");
        }
        
        int total = Integer.parseInt(num);
        
        return total;
    }
    
    // get the count for the current number of events in database
    // this is important - event id will increase by one with each new addition
    public int getEventCount() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select count(*) from event");
        
        String num_events = new String();
        
        while(rs.next()) {
            num_events = rs.getString("count(*)");
        }
        
        int num = Integer.parseInt(num_events);
        
        return num;
        
    }
    
    // get the count for the current holder row position of attendance
    // holder id will increase by one with each new addition when inserted
    public int getHolderCount() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select count(*) from attendance");
        
        String num_holders = new String();
        
        while(rs.next()) {
            num_holders = rs.getString("count(*)");
        }
        
        int num = Integer.parseInt(num_holders);
        
        return num;
        
    }
    
    // create a new ambassador
    public void insertAmbassador(String uin, String firstname, String lastname, String email, 
            String major, String catalog, String grad, String bio, int hours) 
            throws SQLException, ClassNotFoundException {
                
        Statement statement = connection.createStatement();
        
        statement.execute("MERGE INTO AMBASSADOR VALUES('" + uin + "','" + firstname + "','" + lastname + 
                "','" + email + "','" + major + "','" + catalog + "','" + grad + "','" 
                + bio + "','" + hours + "');"
        );
    }

    // get event id based on title
    public int getEventID(String title) 
        throws SQLException, ClassNotFoundException {
        
        // hardcoded example query
        // select id from event
        // where title = 'Sample' // cas sensitive
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select id from event"
                + " where title = '" + title + "';");
        
        String num = new String();
        
        while(rs.next()) {
            num = rs.getString("id");
        }
        
        return Integer.parseInt(num);
    }
    
    // add event attendee to attendance table based on event id
    public void addEventAttendee(int id, String name) 
        throws SQLException, ClassNotFoundException {
                
        Statement statement = connection.createStatement();
        
        ResultSet rs = statement.executeQuery("select count(*) from attendance");
        
        String num = new String();
        
        while(rs.next()) {
            num = rs.getString("count(*)");
        }
        
        int holder_update = Integer.parseInt(num);
        holder_update += 1; // update holder primary key
        
        /* reference table
        statement.execute("create table if not exists attendance (" +
            "holder smallint," +
            "id smallint," +
            "attendees varchar(500)," +
            "constraint pk_holder primary key (holder));"
        );
        */

        statement.execute("MERGE INTO attendance VALUES('" + holder_update + "','" 
            + id + "','" + name + "');"
        );
    }
    
    // get ambassador data into array list
    public ArrayList<String> getAmbassadorData() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select * from ambassador order by lastname");
       
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String uin = rs.getString("uin");
            String firstname = rs.getString("firstname");
            String lastname = rs.getString("lastname");
            String email = rs.getString("email");
            String major = rs.getString("major");
            String catalog = rs.getString("catalog");
            String grad = rs.getString("grad");
            String bio = rs.getString("bio");
            String hours = rs.getString("hours");
            
            list.add(uin);
            list.add(firstname);
            list.add(lastname);
            list.add(email);
            list.add(major);
            list.add(catalog);
            list.add(grad);
            list.add(bio);
            list.add(hours);
        }
        
        return list;
    }
    
    // get event data into array list
    public ArrayList<String> getEventData() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select * from event order by date");
       
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String id = rs.getString("id");
            String title = rs.getString("title");
            String date = rs.getString("date");
            String start = rs.getString("start");
            String until = rs.getString("until");
            String description = rs.getString("description");
            String notes = rs.getString("notes");
            String dress_code = rs.getString("dress_code");
            String address = rs.getString("address");
            String city = rs.getString("city");
            String state = rs.getString("state");
            String zip = rs.getString("zip");
            String attendees = rs.getString("attendees");
            
            list.add(id);
            list.add(title);
            list.add(date);
            list.add(start);
            list.add(until);
            list.add(description);
            list.add(notes);
            list.add(dress_code);
            list.add(address);
            list.add(city);
            list.add(state);
            list.add(zip);
            list.add(attendees);
        }
        
        return list;
    }
    
    // change a specified ambassadors hours
    public void updateAmbassadorHours(String uin, int hours) throws SQLException {
        
        // sample update hours query (hardcoded)
        // UPDATE AMBASSADOR SET HOURS = 3
        // WHERE UIN = 777777999;
        
        Statement statement = connection.createStatement();
        statement.execute("update ambassador set hours = " + hours +
                "where uin = " + uin + ";");
        
    }
    
    // get total hours by ambassador major
    public int getHoursByMajor(String major) throws SQLException {
        
        // select sum(hours) from ambassador
        // where major = 'Software Engineering'
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select sum(hours) from ambassador" +
            " where major = '" + major + "';");
        
        String num = new String();
        
        while(rs.next()) {
            num = rs.getString("sum(hours)");
        }
        
        if(num == null) {
            return 0;
        }
        
        return Integer.parseInt(num);
        
    }
    
    // get ambassador hours based on uin
    public int getAmbassadorHours(String uin) throws SQLException {
        
        // sample get hours query (hardcoded)
        // SELECT HOURS FROM AMBASSADOR
        // WHERE UIN = 815065902;
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select hours from ambassador "
                + "where uin = '" + uin + "';");
        
        String hours = new String();
        
        while(rs.next()) {
            hours = rs.getString("hours");
        }
        
        int hrs = Integer.parseInt(hours);
        
        return hrs;
        
    }
    
    // find an ambassadors uin based on first and last name
    public String getAmbassadorUIN(String firstname, String lastname) throws SQLException {
        
        // find UIN based on first and last name sample query
        // SELECT UIN FROM AMBASSADOR
        // WHERE FIRSTNAME = 'Chelsea' AND LASTNAME = 'Atkins';
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select uin from ambassador "
                + "where firstname = '" + firstname + "' and lastname = '" + lastname + "'");
        
        String uin = new String();
        
        while(rs.next()) {
            uin = rs.getString("uin");
        }
        
        return uin;
    }
    
    // create a new administrator
    public void insertAdmin (String username, String password) throws SQLException, ClassNotFoundException {
        Statement statement = connection.createStatement();
        statement.execute("MERGE INTO ADMIN VALUES('" + username + "','" + password + "');");	
    }
    
    // get data in the log into a list
    public ArrayList<String> getLogData() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select * from actions_hours");
       
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String logged = rs.getString("logged");
            String action = rs.getString("action");
            list.add(logged);
            list.add(action);
        }
        
        return list;
        
    }
    
    // get data in the event attendees log into a list
    public ArrayList<String> getEventsLogData() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select * from actions_attendees");
       
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String index = rs.getString("index");
            String added = rs.getString("added");
            list.add(index);
            list.add(added);
        }
        
        return list;
        
    }
    
    // get administrator data into array list
    public ArrayList<String> getAdminData() throws SQLException {
        
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("select * from admin");
       
        ArrayList<String> list = new ArrayList<>();
        
        while(rs.next()) {
            String username = rs.getString("username");
            String password = rs.getString("password");
            list.add(username);
            list.add(password);
        }
        
        return list;
    }
}
