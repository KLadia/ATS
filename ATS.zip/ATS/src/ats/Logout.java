package ats;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

public class Logout implements Initializable {

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
