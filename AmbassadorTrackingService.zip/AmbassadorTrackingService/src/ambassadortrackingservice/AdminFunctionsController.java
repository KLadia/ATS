package ambassadortrackingservice;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class AdminFunctionsController implements Initializable {


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
        @FXML
    private void home(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("CoordinatorHomepage.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = this.getClass().getResource("CSS.css").toExternalForm(); 
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void createEvent(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("CreateEvent.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = this.getClass().getResource("CSS.css").toExternalForm(); 
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void viewEvents(ActionEvent event) throws IOException {        
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("EventsScreen.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = this.getClass().getResource("CSS.css").toExternalForm(); 
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    
    @FXML
    private void adminFunctions(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("AdminFunctions.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = this.getClass().getResource("CSS.css").toExternalForm(); 
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void signOut(ActionEvent event) throws IOException {        
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
        Scene scene = new Scene(FXMLFrame);
        String css = this.getClass().getResource("CSS.css").toExternalForm(); 
        scene.getStylesheets().add(css);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
        
        // popup with successful logout message
        final Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        Parent FXMLFramePopUp = FXMLLoader.load(getClass().getResource("LogoutPopUp.fxml"));
        Scene popUpScene = new Scene(FXMLFramePopUp);
        popup.setScene(popUpScene);
        popup.show();
    }
}
