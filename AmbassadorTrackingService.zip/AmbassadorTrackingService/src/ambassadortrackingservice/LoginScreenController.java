package ambassadortrackingservice;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.ContextMenu;
import javafx.stage.Modality;


public class LoginScreenController implements Initializable {
                
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    private void login(ActionEvent event) throws IOException {
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("CoordinatorHomepage.fxml"));
        Scene scene = new Scene(FXMLFrame);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    private void completeIntakeApplication(ActionEvent event) throws IOException {
        final Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        Parent FXMLFrame = FXMLLoader.load(getClass().getResource("IntakeApplication.fxml"));
        Scene scene = new Scene(FXMLFrame);
        popup.setScene(scene);
        popup.show();
    }
}
